﻿namespace EwingInventory
{
    partial class Customer_Management
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle9 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle10 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle11 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle12 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle13 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle14 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle15 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle16 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle17 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle18 = new System.Windows.Forms.DataGridViewCellStyle();
            this.tabpmt = new System.Windows.Forms.TabPage();
            this.label43 = new System.Windows.Forms.Label();
            this.lbloutamt = new System.Windows.Forms.Label();
            this.EnteredBy2 = new System.Windows.Forms.TextBox();
            this.txtpmtid = new System.Windows.Forms.TextBox();
            this.txtpmtDate = new System.Windows.Forms.TextBox();
            this.txtpmtamt = new System.Windows.Forms.TextBox();
            this.txtcid3 = new System.Windows.Forms.TextBox();
            this.txtcustpmtdet = new System.Windows.Forms.TextBox();
            this.label40 = new System.Windows.Forms.Label();
            this.cmbdepto = new System.Windows.Forms.ComboBox();
            this.label36 = new System.Windows.Forms.Label();
            this.btnclose3 = new System.Windows.Forms.Button();
            this.label28 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.tpdrawndate = new System.Windows.Forms.DateTimePicker();
            this.label29 = new System.Windows.Forms.Label();
            this.txtcheckNo = new System.Windows.Forms.TextBox();
            this.label30 = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.txtrefNo = new System.Windows.Forms.TextBox();
            this.label31 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.cmbpmtmethod = new System.Windows.Forms.ComboBox();
            this.label33 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.pmtTable = new System.Windows.Forms.DataGridView();
            this.button10 = new System.Windows.Forms.Button();
            this.button11 = new System.Windows.Forms.Button();
            this.button12 = new System.Windows.Forms.Button();
            this.label27 = new System.Windows.Forms.Label();
            this.pmtIDtable = new System.Windows.Forms.DataGridView();
            this.tab_salesorder = new System.Windows.Forms.TabPage();
            this.expDelDate = new System.Windows.Forms.DateTimePicker();
            this.itemtable = new System.Windows.Forms.DataGridView();
            this.search1 = new System.Windows.Forms.GroupBox();
            this.cmbsby = new System.Windows.Forms.ComboBox();
            this.lblsearchby = new System.Windows.Forms.Label();
            this.itemname = new System.Windows.Forms.TextBox();
            this.label39 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.txtsearchinvoice1 = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.txttotqty1 = new System.Windows.Forms.TextBox();
            this.label42 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.cmbdeliverto = new System.Windows.Forms.ComboBox();
            this.btnclose2 = new System.Windows.Forms.Button();
            this.button14 = new System.Windows.Forms.Button();
            this.txtinvoice1 = new System.Windows.Forms.TextBox();
            this.txtremark = new System.Windows.Forms.TextBox();
            this.txtcid1 = new System.Windows.Forms.TextBox();
            this.txtdate1 = new System.Windows.Forms.TextBox();
            this.label26 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.txtSeller1 = new System.Windows.Forms.TextBox();
            this.label25 = new System.Windows.Forms.Label();
            this.txtdue = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.txtnetCost1 = new System.Windows.Forms.TextBox();
            this.txttotalDisc1 = new System.Windows.Forms.TextBox();
            this.txttotalCost1 = new System.Windows.Forms.TextBox();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.InvoiceNotable = new System.Windows.Forms.DataGridView();
            this.label14 = new System.Windows.Forms.Label();
            this.Discount = new System.Windows.Forms.GroupBox();
            this.txtspecPer = new System.Windows.Forms.TextBox();
            this.txtcashDisc = new System.Windows.Forms.TextBox();
            this.txtqtyDisc = new System.Windows.Forms.TextBox();
            this.txtspecDisc = new System.Windows.Forms.TextBox();
            this.cmbpaytype = new System.Windows.Forms.ComboBox();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.cst_tab = new System.Windows.Forms.TabPage();
            this.button15 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.custsearch = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.button7 = new System.Windows.Forms.Button();
            this.button8 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.custTable = new System.Windows.Forms.DataGridView();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label37 = new System.Windows.Forms.Label();
            this.txtentered = new System.Windows.Forms.TextBox();
            this.txtaddress2 = new System.Windows.Forms.TextBox();
            this.txtemail = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.txtcid = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.txtname = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.txtaddress1 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.txtpno1 = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtpno2 = new System.Windows.Forms.TextBox();
            this.tabcontrol_CustMgt = new System.Windows.Forms.TabControl();
            this.tab_Delivery = new System.Windows.Forms.TabPage();
            this.SRoomLoc = new System.Windows.Forms.TextBox();
            this.custnametable = new System.Windows.Forms.DataGridView();
            this.txtciddel = new System.Windows.Forms.TextBox();
            this.label45 = new System.Windows.Forms.Label();
            this.label46 = new System.Windows.Forms.Label();
            this.label48 = new System.Windows.Forms.Label();
            this.txtdeladd = new System.Windows.Forms.TextBox();
            this.label49 = new System.Windows.Forms.Label();
            this.txtdelpno = new System.Windows.Forms.TextBox();
            this.button9 = new System.Windows.Forms.Button();
            this.txtdelsearch = new System.Windows.Forms.TextBox();
            this.label41 = new System.Windows.Forms.Label();
            this.button17 = new System.Windows.Forms.Button();
            this.button18 = new System.Windows.Forms.Button();
            this.button19 = new System.Windows.Forms.Button();
            this.dettable = new System.Windows.Forms.DataGridView();
            this.button16 = new System.Windows.Forms.Button();
            this.tabpmt.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pmtTable)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pmtIDtable)).BeginInit();
            this.tab_salesorder.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.itemtable)).BeginInit();
            this.search1.SuspendLayout();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.InvoiceNotable)).BeginInit();
            this.Discount.SuspendLayout();
            this.cst_tab.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.custTable)).BeginInit();
            this.panel1.SuspendLayout();
            this.tabcontrol_CustMgt.SuspendLayout();
            this.tab_Delivery.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.custnametable)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dettable)).BeginInit();
            this.SuspendLayout();
            // 
            // tabpmt
            // 
            this.tabpmt.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.tabpmt.Controls.Add(this.label43);
            this.tabpmt.Controls.Add(this.lbloutamt);
            this.tabpmt.Controls.Add(this.EnteredBy2);
            this.tabpmt.Controls.Add(this.txtpmtid);
            this.tabpmt.Controls.Add(this.txtpmtDate);
            this.tabpmt.Controls.Add(this.txtpmtamt);
            this.tabpmt.Controls.Add(this.txtcid3);
            this.tabpmt.Controls.Add(this.txtcustpmtdet);
            this.tabpmt.Controls.Add(this.label40);
            this.tabpmt.Controls.Add(this.cmbdepto);
            this.tabpmt.Controls.Add(this.label36);
            this.tabpmt.Controls.Add(this.btnclose3);
            this.tabpmt.Controls.Add(this.label28);
            this.tabpmt.Controls.Add(this.groupBox2);
            this.tabpmt.Controls.Add(this.groupBox3);
            this.tabpmt.Controls.Add(this.label32);
            this.tabpmt.Controls.Add(this.cmbpmtmethod);
            this.tabpmt.Controls.Add(this.label33);
            this.tabpmt.Controls.Add(this.label34);
            this.tabpmt.Controls.Add(this.label35);
            this.tabpmt.Controls.Add(this.pmtTable);
            this.tabpmt.Controls.Add(this.button10);
            this.tabpmt.Controls.Add(this.button11);
            this.tabpmt.Controls.Add(this.button12);
            this.tabpmt.Controls.Add(this.label27);
            this.tabpmt.Controls.Add(this.pmtIDtable);
            this.tabpmt.Location = new System.Drawing.Point(4, 22);
            this.tabpmt.Name = "tabpmt";
            this.tabpmt.Padding = new System.Windows.Forms.Padding(3);
            this.tabpmt.Size = new System.Drawing.Size(1248, 498);
            this.tabpmt.TabIndex = 2;
            this.tabpmt.Text = "Payment";
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label43.Location = new System.Drawing.Point(300, 147);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(167, 19);
            this.label43.TabIndex = 89;
            this.label43.Text = "Total OutStanding Amt ";
            // 
            // lbloutamt
            // 
            this.lbloutamt.AutoSize = true;
            this.lbloutamt.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbloutamt.Location = new System.Drawing.Point(473, 149);
            this.lbloutamt.Name = "lbloutamt";
            this.lbloutamt.Size = new System.Drawing.Size(0, 19);
            this.lbloutamt.TabIndex = 88;
            // 
            // EnteredBy2
            // 
            this.EnteredBy2.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.EnteredBy2.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.EnteredBy2.Location = new System.Drawing.Point(773, 17);
            this.EnteredBy2.Name = "EnteredBy2";
            this.EnteredBy2.Size = new System.Drawing.Size(130, 26);
            this.EnteredBy2.TabIndex = 23;
            // 
            // txtpmtid
            // 
            this.txtpmtid.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.txtpmtid.Enabled = false;
            this.txtpmtid.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtpmtid.Location = new System.Drawing.Point(446, 21);
            this.txtpmtid.Name = "txtpmtid";
            this.txtpmtid.Size = new System.Drawing.Size(130, 26);
            this.txtpmtid.TabIndex = 77;
            this.txtpmtid.TextChanged += new System.EventHandler(this.textBox8_TextChanged);
            // 
            // txtpmtDate
            // 
            this.txtpmtDate.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.txtpmtDate.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtpmtDate.Location = new System.Drawing.Point(446, 52);
            this.txtpmtDate.Name = "txtpmtDate";
            this.txtpmtDate.Size = new System.Drawing.Size(130, 26);
            this.txtpmtDate.TabIndex = 73;
            this.txtpmtDate.TextChanged += new System.EventHandler(this.textBox3_TextChanged);
            // 
            // txtpmtamt
            // 
            this.txtpmtamt.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.txtpmtamt.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtpmtamt.Location = new System.Drawing.Point(446, 116);
            this.txtpmtamt.Name = "txtpmtamt";
            this.txtpmtamt.Size = new System.Drawing.Size(130, 26);
            this.txtpmtamt.TabIndex = 68;
            this.txtpmtamt.TextChanged += new System.EventHandler(this.textBox2_TextChanged);
            this.txtpmtamt.Enter += new System.EventHandler(this.txtpmtamt_Enter);
            this.txtpmtamt.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtpmtamt_KeyDown);
            // 
            // txtcid3
            // 
            this.txtcid3.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.txtcid3.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtcid3.Location = new System.Drawing.Point(446, 84);
            this.txtcid3.Name = "txtcid3";
            this.txtcid3.Size = new System.Drawing.Size(130, 26);
            this.txtcid3.TabIndex = 66;
            this.txtcid3.TextChanged += new System.EventHandler(this.pass_TextChanged);
            // 
            // txtcustpmtdet
            // 
            this.txtcustpmtdet.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.txtcustpmtdet.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtcustpmtdet.Location = new System.Drawing.Point(129, 21);
            this.txtcustpmtdet.Name = "txtcustpmtdet";
            this.txtcustpmtdet.Size = new System.Drawing.Size(164, 26);
            this.txtcustpmtdet.TabIndex = 40;
            this.txtcustpmtdet.TextChanged += new System.EventHandler(this.textBox9_TextChanged);
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label40.Location = new System.Drawing.Point(626, 20);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(95, 19);
            this.label40.TabIndex = 87;
            this.label40.Text = "Enterded By";
            // 
            // cmbdepto
            // 
            this.cmbdepto.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.cmbdepto.FormattingEnabled = true;
            this.cmbdepto.Items.AddRange(new object[] {
            "Cash in hand",
            "Bank"});
            this.cmbdepto.Location = new System.Drawing.Point(1086, 53);
            this.cmbdepto.Name = "cmbdepto";
            this.cmbdepto.Size = new System.Drawing.Size(130, 21);
            this.cmbdepto.TabIndex = 86;
            this.cmbdepto.SelectedIndexChanged += new System.EventHandler(this.comboBox2_SelectedIndexChanged);
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label36.Location = new System.Drawing.Point(940, 53);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(83, 19);
            this.label36.TabIndex = 85;
            this.label36.Text = "Deposit To";
            // 
            // btnclose3
            // 
            this.btnclose3.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.btnclose3.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnclose3.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.btnclose3.Location = new System.Drawing.Point(1099, 441);
            this.btnclose3.Name = "btnclose3";
            this.btnclose3.Size = new System.Drawing.Size(94, 43);
            this.btnclose3.TabIndex = 84;
            this.btnclose3.Text = "Close";
            this.btnclose3.UseVisualStyleBackColor = false;
            this.btnclose3.Click += new System.EventHandler(this.btnclose3_Click);
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label28.Location = new System.Drawing.Point(299, 20);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(89, 19);
            this.label28.TabIndex = 76;
            this.label28.Text = "Payment ID";
            // 
            // groupBox2
            // 
            this.groupBox2.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.groupBox2.Controls.Add(this.tpdrawndate);
            this.groupBox2.Controls.Add(this.label29);
            this.groupBox2.Controls.Add(this.txtcheckNo);
            this.groupBox2.Controls.Add(this.label30);
            this.groupBox2.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.Location = new System.Drawing.Point(941, 87);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(281, 98);
            this.groupBox2.TabIndex = 75;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Check";
            // 
            // tpdrawndate
            // 
            this.tpdrawndate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.tpdrawndate.Location = new System.Drawing.Point(145, 57);
            this.tpdrawndate.MaxDate = new System.DateTime(2100, 12, 31, 0, 0, 0, 0);
            this.tpdrawndate.Name = "tpdrawndate";
            this.tpdrawndate.Size = new System.Drawing.Size(130, 26);
            this.tpdrawndate.TabIndex = 29;
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label29.Location = new System.Drawing.Point(10, 57);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(92, 19);
            this.label29.TabIndex = 28;
            this.label29.Text = "Drawn Date";
            // 
            // txtcheckNo
            // 
            this.txtcheckNo.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtcheckNo.Location = new System.Drawing.Point(145, 25);
            this.txtcheckNo.Name = "txtcheckNo";
            this.txtcheckNo.Size = new System.Drawing.Size(130, 26);
            this.txtcheckNo.TabIndex = 23;
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label30.Location = new System.Drawing.Point(9, 23);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(74, 19);
            this.label30.TabIndex = 24;
            this.label30.Text = "Check No";
            // 
            // groupBox3
            // 
            this.groupBox3.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.groupBox3.Controls.Add(this.txtrefNo);
            this.groupBox3.Controls.Add(this.label31);
            this.groupBox3.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox3.Location = new System.Drawing.Point(633, 87);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(281, 98);
            this.groupBox3.TabIndex = 74;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Cash";
            // 
            // txtrefNo
            // 
            this.txtrefNo.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtrefNo.Location = new System.Drawing.Point(140, 27);
            this.txtrefNo.Name = "txtrefNo";
            this.txtrefNo.Size = new System.Drawing.Size(130, 26);
            this.txtrefNo.TabIndex = 22;
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label31.Location = new System.Drawing.Point(8, 27);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(56, 19);
            this.label31.TabIndex = 22;
            this.label31.Text = "Ref No";
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label32.Location = new System.Drawing.Point(299, 55);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(41, 19);
            this.label32.TabIndex = 72;
            this.label32.Text = "Date";
            this.label32.Click += new System.EventHandler(this.label32_Click);
            // 
            // cmbpmtmethod
            // 
            this.cmbpmtmethod.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.cmbpmtmethod.FormattingEnabled = true;
            this.cmbpmtmethod.Items.AddRange(new object[] {
            "Immediate",
            "Credit"});
            this.cmbpmtmethod.Location = new System.Drawing.Point(773, 55);
            this.cmbpmtmethod.Name = "cmbpmtmethod";
            this.cmbpmtmethod.Size = new System.Drawing.Size(130, 21);
            this.cmbpmtmethod.TabIndex = 71;
            this.cmbpmtmethod.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label33.Location = new System.Drawing.Point(627, 55);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(126, 19);
            this.label33.TabIndex = 70;
            this.label33.Text = "Payment Method";
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label34.Location = new System.Drawing.Point(299, 116);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(64, 19);
            this.label34.TabIndex = 69;
            this.label34.Text = "Amount";
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label35.Location = new System.Drawing.Point(299, 87);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(34, 19);
            this.label35.TabIndex = 67;
            this.label35.Text = "CID";
            // 
            // pmtTable
            // 
            this.pmtTable.BackgroundColor = System.Drawing.SystemColors.GradientInactiveCaption;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.pmtTable.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.pmtTable.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.pmtTable.DefaultCellStyle = dataGridViewCellStyle2;
            this.pmtTable.Location = new System.Drawing.Point(304, 220);
            this.pmtTable.Name = "pmtTable";
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.pmtTable.RowHeadersDefaultCellStyle = dataGridViewCellStyle3;
            this.pmtTable.Size = new System.Drawing.Size(918, 206);
            this.pmtTable.TabIndex = 78;
            this.pmtTable.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.pmtTable_CellContentClick);
            this.pmtTable.Click += new System.EventHandler(this.pmtTable_Click);
            // 
            // button10
            // 
            this.button10.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.button10.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button10.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.button10.Location = new System.Drawing.Point(855, 441);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(94, 43);
            this.button10.TabIndex = 64;
            this.button10.Text = "Clear";
            this.button10.UseVisualStyleBackColor = false;
            this.button10.Click += new System.EventHandler(this.button10_Click);
            // 
            // button11
            // 
            this.button11.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.button11.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button11.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.button11.Location = new System.Drawing.Point(576, 441);
            this.button11.Name = "button11";
            this.button11.Size = new System.Drawing.Size(94, 43);
            this.button11.TabIndex = 65;
            this.button11.Text = "Cancel pmt";
            this.button11.UseVisualStyleBackColor = false;
            this.button11.Click += new System.EventHandler(this.button11_Click);
            // 
            // button12
            // 
            this.button12.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.button12.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button12.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.button12.Location = new System.Drawing.Point(284, 441);
            this.button12.Name = "button12";
            this.button12.Size = new System.Drawing.Size(94, 43);
            this.button12.TabIndex = 63;
            this.button12.Text = "Save";
            this.button12.UseVisualStyleBackColor = false;
            this.button12.Click += new System.EventHandler(this.button12_Click);
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.label27.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label27.Location = new System.Drawing.Point(7, 23);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(116, 19);
            this.label27.TabIndex = 39;
            this.label27.Text = "CustomerName";
            // 
            // pmtIDtable
            // 
            this.pmtIDtable.BackgroundColor = System.Drawing.SystemColors.GradientInactiveCaption;
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle4.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle4.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.pmtIDtable.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle4;
            this.pmtIDtable.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.pmtIDtable.Cursor = System.Windows.Forms.Cursors.Default;
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle5.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle5.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle5.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle5.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle5.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.pmtIDtable.DefaultCellStyle = dataGridViewCellStyle5;
            this.pmtIDtable.GridColor = System.Drawing.SystemColors.ControlLightLight;
            this.pmtIDtable.Location = new System.Drawing.Point(0, 67);
            this.pmtIDtable.Name = "pmtIDtable";
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle6.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle6.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle6.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle6.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle6.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.pmtIDtable.RowHeadersDefaultCellStyle = dataGridViewCellStyle6;
            this.pmtIDtable.RowHeadersWidth = 30;
            this.pmtIDtable.Size = new System.Drawing.Size(297, 359);
            this.pmtIDtable.TabIndex = 1;
            this.pmtIDtable.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.pmtIDtable_CellContentClick);
            this.pmtIDtable.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.pmtIDtable_CellContentClick);
            this.pmtIDtable.ClientSizeChanged += new System.EventHandler(this.pmtIDtable_ClientSizeChanged);
            this.pmtIDtable.Click += new System.EventHandler(this.pmtIDtable_Click);
            // 
            // tab_salesorder
            // 
            this.tab_salesorder.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.tab_salesorder.Controls.Add(this.expDelDate);
            this.tab_salesorder.Controls.Add(this.itemtable);
            this.tab_salesorder.Controls.Add(this.search1);
            this.tab_salesorder.Controls.Add(this.txttotqty1);
            this.tab_salesorder.Controls.Add(this.label42);
            this.tab_salesorder.Controls.Add(this.label24);
            this.tab_salesorder.Controls.Add(this.cmbdeliverto);
            this.tab_salesorder.Controls.Add(this.btnclose2);
            this.tab_salesorder.Controls.Add(this.button14);
            this.tab_salesorder.Controls.Add(this.txtinvoice1);
            this.tab_salesorder.Controls.Add(this.txtremark);
            this.tab_salesorder.Controls.Add(this.txtcid1);
            this.tab_salesorder.Controls.Add(this.txtdate1);
            this.tab_salesorder.Controls.Add(this.label26);
            this.tab_salesorder.Controls.Add(this.label22);
            this.tab_salesorder.Controls.Add(this.button2);
            this.tab_salesorder.Controls.Add(this.button3);
            this.tab_salesorder.Controls.Add(this.button4);
            this.tab_salesorder.Controls.Add(this.groupBox1);
            this.tab_salesorder.Controls.Add(this.label8);
            this.tab_salesorder.Controls.Add(this.InvoiceNotable);
            this.tab_salesorder.Controls.Add(this.label14);
            this.tab_salesorder.Controls.Add(this.Discount);
            this.tab_salesorder.Controls.Add(this.label9);
            this.tab_salesorder.Location = new System.Drawing.Point(4, 22);
            this.tab_salesorder.Name = "tab_salesorder";
            this.tab_salesorder.Padding = new System.Windows.Forms.Padding(3);
            this.tab_salesorder.Size = new System.Drawing.Size(1248, 498);
            this.tab_salesorder.TabIndex = 1;
            this.tab_salesorder.Text = "Sales Order";
            this.tab_salesorder.Click += new System.EventHandler(this.tabPage2_Click);
            // 
            // expDelDate
            // 
            this.expDelDate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.expDelDate.Location = new System.Drawing.Point(748, 376);
            this.expDelDate.MaxDate = new System.DateTime(2100, 12, 31, 0, 0, 0, 0);
            this.expDelDate.Name = "expDelDate";
            this.expDelDate.Size = new System.Drawing.Size(130, 20);
            this.expDelDate.TabIndex = 95;
            this.expDelDate.ValueChanged += new System.EventHandler(this.expDelDate_ValueChanged);
            // 
            // itemtable
            // 
            this.itemtable.BackgroundColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.itemtable.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.itemtable.Location = new System.Drawing.Point(231, 49);
            this.itemtable.Name = "itemtable";
            this.itemtable.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.itemtable.Size = new System.Drawing.Size(717, 301);
            this.itemtable.TabIndex = 94;
            this.itemtable.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.itemtable_CellContentClick);
            this.itemtable.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.itemtable_CellContentClick_1);
            this.itemtable.Click += new System.EventHandler(this.itemtable_Click);
            // 
            // search1
            // 
            this.search1.Controls.Add(this.cmbsby);
            this.search1.Controls.Add(this.lblsearchby);
            this.search1.Controls.Add(this.itemname);
            this.search1.Controls.Add(this.label39);
            this.search1.Controls.Add(this.label18);
            this.search1.Controls.Add(this.txtsearchinvoice1);
            this.search1.Controls.Add(this.label11);
            this.search1.Location = new System.Drawing.Point(3, 17);
            this.search1.Name = "search1";
            this.search1.Size = new System.Drawing.Size(228, 160);
            this.search1.TabIndex = 92;
            this.search1.TabStop = false;
            this.search1.Text = "Search";
            // 
            // cmbsby
            // 
            this.cmbsby.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbsby.FormattingEnabled = true;
            this.cmbsby.Items.AddRange(new object[] {
            "Invoice No",
            "Item Name"});
            this.cmbsby.Location = new System.Drawing.Point(79, 35);
            this.cmbsby.Name = "cmbsby";
            this.cmbsby.Size = new System.Drawing.Size(143, 21);
            this.cmbsby.TabIndex = 95;
            this.cmbsby.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged_1);
            // 
            // lblsearchby
            // 
            this.lblsearchby.AutoSize = true;
            this.lblsearchby.Font = new System.Drawing.Font("Cambria", 11F);
            this.lblsearchby.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lblsearchby.Location = new System.Drawing.Point(0, 35);
            this.lblsearchby.Name = "lblsearchby";
            this.lblsearchby.Size = new System.Drawing.Size(70, 17);
            this.lblsearchby.TabIndex = 43;
            this.lblsearchby.Text = "Search By";
            // 
            // itemname
            // 
            this.itemname.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.itemname.Enabled = false;
            this.itemname.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.itemname.Location = new System.Drawing.Point(79, 115);
            this.itemname.Name = "itemname";
            this.itemname.Size = new System.Drawing.Size(144, 26);
            this.itemname.TabIndex = 42;
            this.itemname.TextChanged += new System.EventHandler(this.itemname_TextChanged);
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Font = new System.Drawing.Font("Cambria", 11F);
            this.label39.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label39.Location = new System.Drawing.Point(0, 124);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(73, 17);
            this.label39.TabIndex = 41;
            this.label39.Text = "ItemName";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.label18.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.Location = new System.Drawing.Point(6, 22);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(0, 19);
            this.label18.TabIndex = 40;
            this.label18.Click += new System.EventHandler(this.label18_Click);
            // 
            // txtsearchinvoice1
            // 
            this.txtsearchinvoice1.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.txtsearchinvoice1.Enabled = false;
            this.txtsearchinvoice1.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtsearchinvoice1.Location = new System.Drawing.Point(79, 74);
            this.txtsearchinvoice1.Name = "txtsearchinvoice1";
            this.txtsearchinvoice1.Size = new System.Drawing.Size(144, 26);
            this.txtsearchinvoice1.TabIndex = 38;
            this.txtsearchinvoice1.TextChanged += new System.EventHandler(this.txtsearchinvoice1_TextChanged);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Cambria", 11F);
            this.label11.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label11.Location = new System.Drawing.Point(0, 78);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(76, 17);
            this.label11.TabIndex = 36;
            this.label11.Text = "Invoice No";
            // 
            // txttotqty1
            // 
            this.txttotqty1.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.txttotqty1.Enabled = false;
            this.txttotqty1.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txttotqty1.Location = new System.Drawing.Point(402, 407);
            this.txttotqty1.Name = "txttotqty1";
            this.txttotqty1.Size = new System.Drawing.Size(125, 26);
            this.txttotqty1.TabIndex = 91;
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Font = new System.Drawing.Font("Cambria", 11F);
            this.label42.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label42.Location = new System.Drawing.Point(316, 407);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(66, 17);
            this.label42.TabIndex = 90;
            this.label42.Text = "Total Qty";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.label24.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label24.Location = new System.Drawing.Point(562, 377);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(162, 19);
            this.label24.TabIndex = 88;
            this.label24.Text = "Expected Deliver Date";
            // 
            // cmbdeliverto
            // 
            this.cmbdeliverto.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.cmbdeliverto.FormattingEnabled = true;
            this.cmbdeliverto.Location = new System.Drawing.Point(406, 375);
            this.cmbdeliverto.Name = "cmbdeliverto";
            this.cmbdeliverto.Size = new System.Drawing.Size(121, 21);
            this.cmbdeliverto.TabIndex = 86;
            this.cmbdeliverto.SelectedIndexChanged += new System.EventHandler(this.cmbdeliverto_SelectedIndexChanged);
            // 
            // btnclose2
            // 
            this.btnclose2.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.btnclose2.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnclose2.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.btnclose2.Location = new System.Drawing.Point(1045, 441);
            this.btnclose2.Name = "btnclose2";
            this.btnclose2.Size = new System.Drawing.Size(94, 43);
            this.btnclose2.TabIndex = 85;
            this.btnclose2.Text = "Close";
            this.btnclose2.UseVisualStyleBackColor = false;
            this.btnclose2.Click += new System.EventHandler(this.button15_Click);
            // 
            // button14
            // 
            this.button14.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.button14.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button14.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.button14.Location = new System.Drawing.Point(316, 442);
            this.button14.Name = "button14";
            this.button14.Size = new System.Drawing.Size(112, 43);
            this.button14.TabIndex = 72;
            this.button14.Text = "Cancel Order";
            this.button14.UseVisualStyleBackColor = false;
            this.button14.Click += new System.EventHandler(this.button14_Click);
            // 
            // txtinvoice1
            // 
            this.txtinvoice1.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.txtinvoice1.Enabled = false;
            this.txtinvoice1.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtinvoice1.Location = new System.Drawing.Point(385, 17);
            this.txtinvoice1.Name = "txtinvoice1";
            this.txtinvoice1.Size = new System.Drawing.Size(130, 26);
            this.txtinvoice1.TabIndex = 71;
            this.txtinvoice1.TextChanged += new System.EventHandler(this.txtinvoice1_TextChanged);
            // 
            // txtremark
            // 
            this.txtremark.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.txtremark.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtremark.Location = new System.Drawing.Point(1008, 17);
            this.txtremark.Name = "txtremark";
            this.txtremark.Size = new System.Drawing.Size(229, 26);
            this.txtremark.TabIndex = 43;
            // 
            // txtcid1
            // 
            this.txtcid1.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.txtcid1.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtcid1.Location = new System.Drawing.Point(586, 16);
            this.txtcid1.Name = "txtcid1";
            this.txtcid1.Size = new System.Drawing.Size(130, 26);
            this.txtcid1.TabIndex = 41;
            // 
            // txtdate1
            // 
            this.txtdate1.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.txtdate1.Enabled = false;
            this.txtdate1.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtdate1.Location = new System.Drawing.Point(788, 17);
            this.txtdate1.Name = "txtdate1";
            this.txtdate1.Size = new System.Drawing.Size(130, 26);
            this.txtdate1.TabIndex = 39;
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Font = new System.Drawing.Font("Cambria", 11F);
            this.label26.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label26.Location = new System.Drawing.Point(299, 17);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(76, 17);
            this.label26.TabIndex = 70;
            this.label26.Text = "Invoice No";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.label22.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.Location = new System.Drawing.Point(312, 373);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(80, 19);
            this.label22.TabIndex = 66;
            this.label22.Text = "Deliver To";
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.button2.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.button2.Location = new System.Drawing.Point(803, 441);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(94, 43);
            this.button2.TabIndex = 61;
            this.button2.Text = "Clear";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.button3.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.button3.Location = new System.Drawing.Point(566, 441);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(94, 43);
            this.button3.TabIndex = 61;
            this.button3.Text = "Print Bill";
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.button4.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button4.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.button4.Location = new System.Drawing.Point(75, 441);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(94, 43);
            this.button4.TabIndex = 60;
            this.button4.Text = "Save";
            this.button4.UseVisualStyleBackColor = false;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.groupBox1.Controls.Add(this.txtSeller1);
            this.groupBox1.Controls.Add(this.label25);
            this.groupBox1.Controls.Add(this.txtdue);
            this.groupBox1.Controls.Add(this.label16);
            this.groupBox1.Controls.Add(this.txtnetCost1);
            this.groupBox1.Controls.Add(this.txttotalDisc1);
            this.groupBox1.Controls.Add(this.txttotalCost1);
            this.groupBox1.Controls.Add(this.label19);
            this.groupBox1.Controls.Add(this.label20);
            this.groupBox1.Controls.Add(this.label21);
            this.groupBox1.Controls.Add(this.label23);
            this.groupBox1.Font = new System.Drawing.Font("Cambria", 13F);
            this.groupBox1.Location = new System.Drawing.Point(954, 226);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(296, 198);
            this.groupBox1.TabIndex = 44;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Cost Details";
            this.groupBox1.Enter += new System.EventHandler(this.groupBox1_Enter);
            // 
            // txtSeller1
            // 
            this.txtSeller1.Location = new System.Drawing.Point(106, 125);
            this.txtSeller1.Name = "txtSeller1";
            this.txtSeller1.Size = new System.Drawing.Size(130, 28);
            this.txtSeller1.TabIndex = 37;
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("Cambria", 11F);
            this.label25.Location = new System.Drawing.Point(240, 165);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(56, 17);
            this.label25.TabIndex = 36;
            this.label25.Text = "90 days";
            // 
            // txtdue
            // 
            this.txtdue.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.txtdue.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtdue.Location = new System.Drawing.Point(106, 161);
            this.txtdue.Name = "txtdue";
            this.txtdue.Size = new System.Drawing.Size(130, 26);
            this.txtdue.TabIndex = 34;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Cambria", 11F);
            this.label16.Location = new System.Drawing.Point(10, 161);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(65, 17);
            this.label16.TabIndex = 35;
            this.label16.Text = "Due Date";
            // 
            // txtnetCost1
            // 
            this.txtnetCost1.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.txtnetCost1.Enabled = false;
            this.txtnetCost1.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtnetCost1.Location = new System.Drawing.Point(106, 93);
            this.txtnetCost1.Name = "txtnetCost1";
            this.txtnetCost1.Size = new System.Drawing.Size(130, 26);
            this.txtnetCost1.TabIndex = 28;
            // 
            // txttotalDisc1
            // 
            this.txttotalDisc1.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.txttotalDisc1.Enabled = false;
            this.txttotalDisc1.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txttotalDisc1.Location = new System.Drawing.Point(106, 61);
            this.txttotalDisc1.Name = "txttotalDisc1";
            this.txttotalDisc1.Size = new System.Drawing.Size(130, 26);
            this.txttotalDisc1.TabIndex = 27;
            // 
            // txttotalCost1
            // 
            this.txttotalCost1.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.txttotalCost1.Enabled = false;
            this.txttotalCost1.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txttotalCost1.Location = new System.Drawing.Point(106, 29);
            this.txttotalCost1.Name = "txttotalCost1";
            this.txttotalCost1.Size = new System.Drawing.Size(130, 26);
            this.txttotalCost1.TabIndex = 26;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Cambria", 11F);
            this.label19.Location = new System.Drawing.Point(10, 29);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(70, 17);
            this.label19.TabIndex = 23;
            this.label19.Text = "Total Cost";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Cambria", 11F);
            this.label20.Location = new System.Drawing.Point(9, 125);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(66, 17);
            this.label20.TabIndex = 22;
            this.label20.Text = "Sales Rep";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Cambria", 11F);
            this.label21.Location = new System.Drawing.Point(9, 93);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(60, 17);
            this.label21.TabIndex = 21;
            this.label21.Text = "Net Cost";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Cambria", 11F);
            this.label23.Location = new System.Drawing.Point(10, 61);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(99, 17);
            this.label23.TabIndex = 19;
            this.label23.Text = "Total Discount";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Cambria", 11F);
            this.label8.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label8.Location = new System.Drawing.Point(945, 16);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(57, 17);
            this.label8.TabIndex = 42;
            this.label8.Text = "Remark";
            // 
            // InvoiceNotable
            // 
            this.InvoiceNotable.BackgroundColor = System.Drawing.SystemColors.GradientInactiveCaption;
            dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle7.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle7.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle7.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle7.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle7.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle7.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.InvoiceNotable.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle7;
            this.InvoiceNotable.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.InvoiceNotable.Cursor = System.Windows.Forms.Cursors.Default;
            dataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle8.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle8.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle8.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle8.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle8.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle8.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.InvoiceNotable.DefaultCellStyle = dataGridViewCellStyle8;
            this.InvoiceNotable.GridColor = System.Drawing.SystemColors.ControlLightLight;
            this.InvoiceNotable.Location = new System.Drawing.Point(0, 183);
            this.InvoiceNotable.Name = "InvoiceNotable";
            dataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle9.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle9.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle9.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle9.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle9.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle9.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.InvoiceNotable.RowHeadersDefaultCellStyle = dataGridViewCellStyle9;
            this.InvoiceNotable.RowHeadersWidth = 30;
            this.InvoiceNotable.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.InvoiceNotable.Size = new System.Drawing.Size(228, 247);
            this.InvoiceNotable.TabIndex = 43;
            this.InvoiceNotable.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.InvoiceNotable_CellContentClick);
            this.InvoiceNotable.Click += new System.EventHandler(this.InvoiceNotable_Click);
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Cambria", 11F);
            this.label14.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label14.Location = new System.Drawing.Point(549, 17);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(31, 17);
            this.label14.TabIndex = 40;
            this.label14.Text = "CID";
            // 
            // Discount
            // 
            this.Discount.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.Discount.Controls.Add(this.txtspecPer);
            this.Discount.Controls.Add(this.txtcashDisc);
            this.Discount.Controls.Add(this.txtqtyDisc);
            this.Discount.Controls.Add(this.txtspecDisc);
            this.Discount.Controls.Add(this.cmbpaytype);
            this.Discount.Controls.Add(this.label12);
            this.Discount.Controls.Add(this.label13);
            this.Discount.Controls.Add(this.label15);
            this.Discount.Controls.Add(this.label17);
            this.Discount.Font = new System.Drawing.Font("Cambria", 13F);
            this.Discount.Location = new System.Drawing.Point(954, 52);
            this.Discount.Name = "Discount";
            this.Discount.Size = new System.Drawing.Size(296, 168);
            this.Discount.TabIndex = 41;
            this.Discount.TabStop = false;
            this.Discount.Text = "Discount";
            // 
            // txtspecPer
            // 
            this.txtspecPer.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.txtspecPer.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtspecPer.Location = new System.Drawing.Point(243, 67);
            this.txtspecPer.Name = "txtspecPer";
            this.txtspecPer.Size = new System.Drawing.Size(41, 26);
            this.txtspecPer.TabIndex = 22;
            this.txtspecPer.TextChanged += new System.EventHandler(this.txtspecPer_TextChanged);
            this.txtspecPer.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtspecPer_KeyDown);
            // 
            // txtcashDisc
            // 
            this.txtcashDisc.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.txtcashDisc.Enabled = false;
            this.txtcashDisc.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtcashDisc.Location = new System.Drawing.Point(107, 131);
            this.txtcashDisc.Name = "txtcashDisc";
            this.txtcashDisc.Size = new System.Drawing.Size(130, 26);
            this.txtcashDisc.TabIndex = 21;
            // 
            // txtqtyDisc
            // 
            this.txtqtyDisc.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.txtqtyDisc.Enabled = false;
            this.txtqtyDisc.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtqtyDisc.Location = new System.Drawing.Point(107, 99);
            this.txtqtyDisc.Name = "txtqtyDisc";
            this.txtqtyDisc.Size = new System.Drawing.Size(130, 26);
            this.txtqtyDisc.TabIndex = 20;
            // 
            // txtspecDisc
            // 
            this.txtspecDisc.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.txtspecDisc.Enabled = false;
            this.txtspecDisc.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtspecDisc.Location = new System.Drawing.Point(107, 67);
            this.txtspecDisc.Name = "txtspecDisc";
            this.txtspecDisc.Size = new System.Drawing.Size(130, 26);
            this.txtspecDisc.TabIndex = 19;
            this.txtspecDisc.Text = "0";
            // 
            // cmbpaytype
            // 
            this.cmbpaytype.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.cmbpaytype.FormattingEnabled = true;
            this.cmbpaytype.Items.AddRange(new object[] {
            "Immediate",
            "Credit"});
            this.cmbpaytype.Location = new System.Drawing.Point(107, 28);
            this.cmbpaytype.Name = "cmbpaytype";
            this.cmbpaytype.Size = new System.Drawing.Size(130, 28);
            this.cmbpaytype.TabIndex = 18;
            this.cmbpaytype.SelectedIndexChanged += new System.EventHandler(this.cmbpaytype_SelectedIndexChanged);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Cambria", 11F);
            this.label12.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label12.Location = new System.Drawing.Point(10, 28);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(64, 17);
            this.label12.TabIndex = 14;
            this.label12.Text = "Payment";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Cambria", 11F);
            this.label13.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label13.Location = new System.Drawing.Point(10, 67);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(82, 17);
            this.label13.TabIndex = 15;
            this.label13.Text = "Special Disc";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Cambria", 11F);
            this.label15.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label15.Location = new System.Drawing.Point(10, 102);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(93, 17);
            this.label15.TabIndex = 16;
            this.label15.Text = "Quantity Disc";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Cambria", 11F);
            this.label17.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label17.Location = new System.Drawing.Point(10, 138);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(67, 17);
            this.label17.TabIndex = 17;
            this.label17.Text = "Cash Disc";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Cambria", 11F);
            this.label9.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label9.Location = new System.Drawing.Point(745, 17);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(37, 17);
            this.label9.TabIndex = 37;
            this.label9.Text = "Date";
            // 
            // cst_tab
            // 
            this.cst_tab.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.cst_tab.Controls.Add(this.button15);
            this.cst_tab.Controls.Add(this.button1);
            this.cst_tab.Controls.Add(this.custsearch);
            this.cst_tab.Controls.Add(this.label5);
            this.cst_tab.Controls.Add(this.button7);
            this.cst_tab.Controls.Add(this.button8);
            this.cst_tab.Controls.Add(this.button6);
            this.cst_tab.Controls.Add(this.custTable);
            this.cst_tab.Controls.Add(this.panel1);
            this.cst_tab.Location = new System.Drawing.Point(4, 22);
            this.cst_tab.Name = "cst_tab";
            this.cst_tab.Padding = new System.Windows.Forms.Padding(3);
            this.cst_tab.Size = new System.Drawing.Size(1248, 498);
            this.cst_tab.TabIndex = 0;
            this.cst_tab.Text = "Customer";
            this.cst_tab.Click += new System.EventHandler(this.tabPage1_Click);
            // 
            // button15
            // 
            this.button15.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.button15.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button15.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.button15.Location = new System.Drawing.Point(993, 441);
            this.button15.Name = "button15";
            this.button15.Size = new System.Drawing.Size(94, 43);
            this.button15.TabIndex = 85;
            this.button15.Text = "Close";
            this.button15.UseVisualStyleBackColor = false;
            this.button15.Click += new System.EventHandler(this.button15_Click_1);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.SystemColors.Control;
            this.button1.BackgroundImage = global::EwingInventory.Properties.Resources.icon_search;
            this.button1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button1.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.button1.Location = new System.Drawing.Point(356, 379);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(30, 26);
            this.button1.TabIndex = 62;
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // custsearch
            // 
            this.custsearch.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.custsearch.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.custsearch.Location = new System.Drawing.Point(127, 379);
            this.custsearch.Name = "custsearch";
            this.custsearch.Size = new System.Drawing.Size(223, 26);
            this.custsearch.TabIndex = 61;
            this.custsearch.TextChanged += new System.EventHandler(this.custsearch_TextChanged);
            this.custsearch.KeyDown += new System.Windows.Forms.KeyEventHandler(this.custsearch_KeyDown);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Cambria", 11F);
            this.label5.Location = new System.Drawing.Point(6, 379);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(107, 17);
            this.label5.TabIndex = 60;
            this.label5.Text = "Customer Name";
            // 
            // button7
            // 
            this.button7.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.button7.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button7.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.button7.Location = new System.Drawing.Point(700, 441);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(94, 43);
            this.button7.TabIndex = 58;
            this.button7.Text = "Clear";
            this.button7.UseVisualStyleBackColor = false;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // button8
            // 
            this.button8.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.button8.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button8.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.button8.Location = new System.Drawing.Point(409, 441);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(94, 43);
            this.button8.TabIndex = 59;
            this.button8.Text = "Delete";
            this.button8.UseVisualStyleBackColor = false;
            this.button8.Click += new System.EventHandler(this.button8_Click);
            // 
            // button6
            // 
            this.button6.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.button6.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button6.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.button6.Location = new System.Drawing.Point(131, 441);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(94, 43);
            this.button6.TabIndex = 57;
            this.button6.Text = "Save";
            this.button6.UseVisualStyleBackColor = false;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // custTable
            // 
            this.custTable.AllowUserToOrderColumns = true;
            this.custTable.BackgroundColor = System.Drawing.SystemColors.GradientInactiveCaption;
            dataGridViewCellStyle10.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle10.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle10.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle10.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle10.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle10.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle10.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.custTable.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle10;
            this.custTable.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle11.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle11.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle11.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle11.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle11.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle11.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle11.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.custTable.DefaultCellStyle = dataGridViewCellStyle11;
            this.custTable.Location = new System.Drawing.Point(369, 6);
            this.custTable.Name = "custTable";
            dataGridViewCellStyle12.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle12.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle12.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle12.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle12.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle12.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle12.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.custTable.RowHeadersDefaultCellStyle = dataGridViewCellStyle12;
            this.custTable.Size = new System.Drawing.Size(876, 359);
            this.custTable.TabIndex = 56;
            this.custTable.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            this.custTable.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            this.custTable.Click += new System.EventHandler(this.custTable_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.panel1.Controls.Add(this.label37);
            this.panel1.Controls.Add(this.txtentered);
            this.panel1.Controls.Add(this.txtaddress2);
            this.panel1.Controls.Add(this.txtemail);
            this.panel1.Controls.Add(this.label7);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.txtcid);
            this.panel1.Controls.Add(this.label10);
            this.panel1.Controls.Add(this.txtname);
            this.panel1.Controls.Add(this.label6);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.txtaddress1);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.txtpno1);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.txtpno2);
            this.panel1.Location = new System.Drawing.Point(6, 6);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(357, 359);
            this.panel1.TabIndex = 50;
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Font = new System.Drawing.Font("Cambria", 11F);
            this.label37.Location = new System.Drawing.Point(8, 192);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(58, 17);
            this.label37.TabIndex = 27;
            this.label37.Text = "Address";
            // 
            // txtentered
            // 
            this.txtentered.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtentered.Location = new System.Drawing.Point(120, 260);
            this.txtentered.Name = "txtentered";
            this.txtentered.Size = new System.Drawing.Size(223, 26);
            this.txtentered.TabIndex = 7;
            this.txtentered.TextChanged += new System.EventHandler(this.txtentered_TextChanged);
            this.txtentered.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtentered_KeyDown);
            // 
            // txtaddress2
            // 
            this.txtaddress2.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtaddress2.Location = new System.Drawing.Point(120, 196);
            this.txtaddress2.Name = "txtaddress2";
            this.txtaddress2.Size = new System.Drawing.Size(223, 26);
            this.txtaddress2.TabIndex = 5;
            this.txtaddress2.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtaddress2_KeyDown);
            // 
            // txtemail
            // 
            this.txtemail.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtemail.Location = new System.Drawing.Point(120, 228);
            this.txtemail.Name = "txtemail";
            this.txtemail.Size = new System.Drawing.Size(223, 26);
            this.txtemail.TabIndex = 6;
            this.txtemail.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtemail_KeyDown_1);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Cambria", 11F);
            this.label7.Location = new System.Drawing.Point(8, 260);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(78, 17);
            this.label7.TabIndex = 26;
            this.label7.Text = "Entered By";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Cambria", 11F);
            this.label4.Location = new System.Drawing.Point(8, 228);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(44, 17);
            this.label4.TabIndex = 24;
            this.label4.Text = "Email";
            // 
            // txtcid
            // 
            this.txtcid.Enabled = false;
            this.txtcid.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtcid.Location = new System.Drawing.Point(120, 29);
            this.txtcid.Name = "txtcid";
            this.txtcid.Size = new System.Drawing.Size(223, 26);
            this.txtcid.TabIndex = 23;
            this.txtcid.TextChanged += new System.EventHandler(this.txtcid_TextChanged);
            this.txtcid.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtcid_KeyDown);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Cambria", 11F);
            this.label10.Location = new System.Drawing.Point(8, 29);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(31, 17);
            this.label10.TabIndex = 22;
            this.label10.Text = "CID";
            // 
            // txtname
            // 
            this.txtname.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtname.Location = new System.Drawing.Point(120, 62);
            this.txtname.Name = "txtname";
            this.txtname.Size = new System.Drawing.Size(223, 26);
            this.txtname.TabIndex = 1;
            this.txtname.TextChanged += new System.EventHandler(this.txtname_TextChanged);
            this.txtname.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtname_KeyDown_1);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Cambria", 11F);
            this.label6.Location = new System.Drawing.Point(8, 62);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(44, 17);
            this.label6.TabIndex = 18;
            this.label6.Text = "Name";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Cambria", 11F);
            this.label3.Location = new System.Drawing.Point(8, 163);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(106, 17);
            this.label3.TabIndex = 14;
            this.label3.Text = "Company Name";
            // 
            // txtaddress1
            // 
            this.txtaddress1.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtaddress1.Location = new System.Drawing.Point(120, 163);
            this.txtaddress1.Name = "txtaddress1";
            this.txtaddress1.Size = new System.Drawing.Size(223, 26);
            this.txtaddress1.TabIndex = 4;
            this.txtaddress1.TextChanged += new System.EventHandler(this.txtaddress1_TextChanged);
            this.txtaddress1.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtaddress1_KeyDown);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Cambria", 11F);
            this.label1.Location = new System.Drawing.Point(8, 95);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(77, 17);
            this.label1.TabIndex = 10;
            this.label1.Text = "Phone No1";
            // 
            // txtpno1
            // 
            this.txtpno1.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtpno1.Location = new System.Drawing.Point(120, 95);
            this.txtpno1.Name = "txtpno1";
            this.txtpno1.Size = new System.Drawing.Size(223, 26);
            this.txtpno1.TabIndex = 2;
            this.txtpno1.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtpno1_KeyDown_1);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Cambria", 11F);
            this.label2.Location = new System.Drawing.Point(8, 129);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(77, 17);
            this.label2.TabIndex = 12;
            this.label2.Text = "Phone No2";
            // 
            // txtpno2
            // 
            this.txtpno2.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtpno2.Location = new System.Drawing.Point(120, 129);
            this.txtpno2.Name = "txtpno2";
            this.txtpno2.Size = new System.Drawing.Size(223, 26);
            this.txtpno2.TabIndex = 3;
            this.txtpno2.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtpno2_KeyDown_1);
            // 
            // tabcontrol_CustMgt
            // 
            this.tabcontrol_CustMgt.Controls.Add(this.cst_tab);
            this.tabcontrol_CustMgt.Controls.Add(this.tab_salesorder);
            this.tabcontrol_CustMgt.Controls.Add(this.tabpmt);
            this.tabcontrol_CustMgt.Controls.Add(this.tab_Delivery);
            this.tabcontrol_CustMgt.Location = new System.Drawing.Point(-1, 4);
            this.tabcontrol_CustMgt.Name = "tabcontrol_CustMgt";
            this.tabcontrol_CustMgt.SelectedIndex = 0;
            this.tabcontrol_CustMgt.Size = new System.Drawing.Size(1256, 524);
            this.tabcontrol_CustMgt.TabIndex = 0;
            this.tabcontrol_CustMgt.SelectedIndexChanged += new System.EventHandler(this.tabControl1_SelectedIndexChanged);
            // 
            // tab_Delivery
            // 
            this.tab_Delivery.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.tab_Delivery.Controls.Add(this.SRoomLoc);
            this.tab_Delivery.Controls.Add(this.custnametable);
            this.tab_Delivery.Controls.Add(this.txtciddel);
            this.tab_Delivery.Controls.Add(this.label45);
            this.tab_Delivery.Controls.Add(this.label46);
            this.tab_Delivery.Controls.Add(this.label48);
            this.tab_Delivery.Controls.Add(this.txtdeladd);
            this.tab_Delivery.Controls.Add(this.label49);
            this.tab_Delivery.Controls.Add(this.txtdelpno);
            this.tab_Delivery.Controls.Add(this.button9);
            this.tab_Delivery.Controls.Add(this.txtdelsearch);
            this.tab_Delivery.Controls.Add(this.label41);
            this.tab_Delivery.Controls.Add(this.button17);
            this.tab_Delivery.Controls.Add(this.button18);
            this.tab_Delivery.Controls.Add(this.button19);
            this.tab_Delivery.Controls.Add(this.dettable);
            this.tab_Delivery.Controls.Add(this.button16);
            this.tab_Delivery.Location = new System.Drawing.Point(4, 22);
            this.tab_Delivery.Name = "tab_Delivery";
            this.tab_Delivery.Padding = new System.Windows.Forms.Padding(3);
            this.tab_Delivery.Size = new System.Drawing.Size(1248, 498);
            this.tab_Delivery.TabIndex = 4;
            this.tab_Delivery.Text = "DeliveryDetails";
            this.tab_Delivery.Click += new System.EventHandler(this.tabPage5_Click);
            // 
            // SRoomLoc
            // 
            this.SRoomLoc.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.SRoomLoc.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SRoomLoc.Location = new System.Drawing.Point(694, 53);
            this.SRoomLoc.Name = "SRoomLoc";
            this.SRoomLoc.Size = new System.Drawing.Size(113, 26);
            this.SRoomLoc.TabIndex = 95;
            // 
            // custnametable
            // 
            this.custnametable.BackgroundColor = System.Drawing.SystemColors.GradientInactiveCaption;
            dataGridViewCellStyle13.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle13.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle13.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle13.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle13.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle13.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle13.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.custnametable.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle13;
            this.custnametable.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.custnametable.Cursor = System.Windows.Forms.Cursors.Default;
            dataGridViewCellStyle14.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle14.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle14.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle14.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle14.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle14.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle14.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.custnametable.DefaultCellStyle = dataGridViewCellStyle14;
            this.custnametable.GridColor = System.Drawing.SystemColors.ControlLightLight;
            this.custnametable.Location = new System.Drawing.Point(95, 85);
            this.custnametable.Name = "custnametable";
            dataGridViewCellStyle15.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle15.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle15.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle15.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle15.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle15.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle15.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.custnametable.RowHeadersDefaultCellStyle = dataGridViewCellStyle15;
            this.custnametable.RowHeadersWidth = 30;
            this.custnametable.Size = new System.Drawing.Size(310, 311);
            this.custnametable.TabIndex = 94;
            // 
            // txtciddel
            // 
            this.txtciddel.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.txtciddel.Enabled = false;
            this.txtciddel.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtciddel.Location = new System.Drawing.Point(694, 23);
            this.txtciddel.Name = "txtciddel";
            this.txtciddel.Size = new System.Drawing.Size(113, 26);
            this.txtciddel.TabIndex = 93;
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.Font = new System.Drawing.Font("Cambria", 11F);
            this.label45.Location = new System.Drawing.Point(542, 23);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(31, 17);
            this.label45.TabIndex = 92;
            this.label45.Text = "CID";
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.label46.Font = new System.Drawing.Font("Cambria", 11F);
            this.label46.Location = new System.Drawing.Point(542, 56);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(141, 17);
            this.label46.TabIndex = 90;
            this.label46.Text = "Show Room Location";
            // 
            // label48
            // 
            this.label48.AutoSize = true;
            this.label48.Font = new System.Drawing.Font("Cambria", 11F);
            this.label48.Location = new System.Drawing.Point(894, 22);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(58, 17);
            this.label48.TabIndex = 87;
            this.label48.Text = "Address";
            // 
            // txtdeladd
            // 
            this.txtdeladd.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.txtdeladd.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtdeladd.Location = new System.Drawing.Point(983, 22);
            this.txtdeladd.Name = "txtdeladd";
            this.txtdeladd.Size = new System.Drawing.Size(223, 26);
            this.txtdeladd.TabIndex = 86;
            // 
            // label49
            // 
            this.label49.AutoSize = true;
            this.label49.Font = new System.Drawing.Font("Cambria", 11F);
            this.label49.Location = new System.Drawing.Point(894, 56);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(69, 17);
            this.label49.TabIndex = 89;
            this.label49.Text = "Phone No";
            // 
            // txtdelpno
            // 
            this.txtdelpno.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.txtdelpno.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtdelpno.Location = new System.Drawing.Point(983, 56);
            this.txtdelpno.Name = "txtdelpno";
            this.txtdelpno.Size = new System.Drawing.Size(223, 26);
            this.txtdelpno.TabIndex = 88;
            // 
            // button9
            // 
            this.button9.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.button9.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button9.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.button9.Location = new System.Drawing.Point(993, 441);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(94, 43);
            this.button9.TabIndex = 85;
            this.button9.Text = "Close";
            this.button9.UseVisualStyleBackColor = false;
            // 
            // txtdelsearch
            // 
            this.txtdelsearch.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.txtdelsearch.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtdelsearch.Location = new System.Drawing.Point(95, 52);
            this.txtdelsearch.Name = "txtdelsearch";
            this.txtdelsearch.Size = new System.Drawing.Size(274, 26);
            this.txtdelsearch.TabIndex = 61;
            this.txtdelsearch.TextChanged += new System.EventHandler(this.textBox6_TextChanged);
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Font = new System.Drawing.Font("Cambria", 11F);
            this.label41.Location = new System.Drawing.Point(92, 22);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(107, 17);
            this.label41.TabIndex = 60;
            this.label41.Text = "Customer Name";
            // 
            // button17
            // 
            this.button17.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.button17.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button17.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.button17.Location = new System.Drawing.Point(688, 441);
            this.button17.Name = "button17";
            this.button17.Size = new System.Drawing.Size(94, 43);
            this.button17.TabIndex = 58;
            this.button17.Text = "Clear";
            this.button17.UseVisualStyleBackColor = false;
            // 
            // button18
            // 
            this.button18.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.button18.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button18.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.button18.Location = new System.Drawing.Point(409, 441);
            this.button18.Name = "button18";
            this.button18.Size = new System.Drawing.Size(94, 43);
            this.button18.TabIndex = 59;
            this.button18.Text = "Delete";
            this.button18.UseVisualStyleBackColor = false;
            this.button18.Click += new System.EventHandler(this.button18_Click);
            // 
            // button19
            // 
            this.button19.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.button19.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button19.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.button19.Location = new System.Drawing.Point(131, 441);
            this.button19.Name = "button19";
            this.button19.Size = new System.Drawing.Size(94, 43);
            this.button19.TabIndex = 57;
            this.button19.Text = "Save";
            this.button19.UseVisualStyleBackColor = false;
            this.button19.Click += new System.EventHandler(this.button19_Click);
            // 
            // dettable
            // 
            this.dettable.AllowUserToOrderColumns = true;
            this.dettable.BackgroundColor = System.Drawing.SystemColors.GradientInactiveCaption;
            dataGridViewCellStyle16.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle16.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle16.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle16.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle16.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle16.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle16.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dettable.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle16;
            this.dettable.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle17.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle17.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle17.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle17.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle17.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle17.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle17.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dettable.DefaultCellStyle = dataGridViewCellStyle17;
            this.dettable.Location = new System.Drawing.Point(544, 105);
            this.dettable.Name = "dettable";
            dataGridViewCellStyle18.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle18.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle18.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle18.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle18.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle18.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle18.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dettable.RowHeadersDefaultCellStyle = dataGridViewCellStyle18;
            this.dettable.Size = new System.Drawing.Size(663, 291);
            this.dettable.TabIndex = 56;
            this.dettable.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dettable_CellContentClick);
            this.dettable.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dettable_CellContentClick);
            // 
            // button16
            // 
            this.button16.BackColor = System.Drawing.SystemColors.Control;
            this.button16.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button16.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.button16.Location = new System.Drawing.Point(375, 53);
            this.button16.Name = "button16";
            this.button16.Size = new System.Drawing.Size(30, 26);
            this.button16.TabIndex = 62;
            this.button16.UseVisualStyleBackColor = false;
            // 
            // Customer_Management
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Control;
            this.ClientSize = new System.Drawing.Size(1256, 521);
            this.Controls.Add(this.tabcontrol_CustMgt);
            this.MaximizeBox = false;
            this.Name = "Customer_Management";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Customer_Management";
            this.Load += new System.EventHandler(this.Customer_Management_Load);
            this.tabpmt.ResumeLayout(false);
            this.tabpmt.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pmtTable)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pmtIDtable)).EndInit();
            this.tab_salesorder.ResumeLayout(false);
            this.tab_salesorder.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.itemtable)).EndInit();
            this.search1.ResumeLayout(false);
            this.search1.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.InvoiceNotable)).EndInit();
            this.Discount.ResumeLayout(false);
            this.Discount.PerformLayout();
            this.cst_tab.ResumeLayout(false);
            this.cst_tab.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.custTable)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.tabcontrol_CustMgt.ResumeLayout(false);
            this.tab_Delivery.ResumeLayout(false);
            this.tab_Delivery.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.custnametable)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dettable)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabPage tabpmt;
        private System.Windows.Forms.TextBox EnteredBy2;
        private System.Windows.Forms.TextBox txtpmtid;
        private System.Windows.Forms.TextBox txtpmtDate;
        private System.Windows.Forms.TextBox txtpmtamt;
        private System.Windows.Forms.TextBox txtcid3;
        private System.Windows.Forms.TextBox txtcustpmtdet;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.ComboBox cmbdepto;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Button btnclose3;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.DateTimePicker tpdrawndate;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.TextBox txtcheckNo;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.TextBox txtrefNo;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.ComboBox cmbpmtmethod;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.DataGridView pmtTable;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.Button button11;
        private System.Windows.Forms.Button button12;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.DataGridView pmtIDtable;
        private System.Windows.Forms.TabPage tab_salesorder;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.ComboBox cmbdeliverto;
        private System.Windows.Forms.Button btnclose2;
        private System.Windows.Forms.Button button14;
        private System.Windows.Forms.TextBox txtremark;
        private System.Windows.Forms.TextBox txtdate1;
        private System.Windows.Forms.TextBox txtsearchinvoice1;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.TextBox txtdue;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TextBox txtnetCost1;
        private System.Windows.Forms.TextBox txttotalDisc1;
        private System.Windows.Forms.TextBox txttotalCost1;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.GroupBox Discount;
        private System.Windows.Forms.TextBox txtspecPer;
        private System.Windows.Forms.TextBox txtcashDisc;
        private System.Windows.Forms.TextBox txtqtyDisc;
        private System.Windows.Forms.TextBox txtspecDisc;
        private System.Windows.Forms.ComboBox cmbpaytype;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Button button15;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox custsearch;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.DataGridView custTable;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TextBox txtentered;
        private System.Windows.Forms.TextBox txtaddress2;
        private System.Windows.Forms.TextBox txtemail;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtcid;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox txtname;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtaddress1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtpno1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtpno2;
        private System.Windows.Forms.TabPage tab_Delivery;
        private System.Windows.Forms.DataGridView custnametable;
        private System.Windows.Forms.TextBox txtciddel;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.Label label48;
        private System.Windows.Forms.TextBox txtdeladd;
        private System.Windows.Forms.Label label49;
        private System.Windows.Forms.TextBox txtdelpno;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Button button16;
        private System.Windows.Forms.TextBox txtdelsearch;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.Button button17;
        private System.Windows.Forms.Button button18;
        private System.Windows.Forms.Button button19;
        private System.Windows.Forms.DataGridView dettable;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.Label lbloutamt;
        private System.Windows.Forms.GroupBox search1;
        private System.Windows.Forms.TextBox SRoomLoc;
        public System.Windows.Forms.TextBox txttotqty1;
        public System.Windows.Forms.TextBox txtinvoice1;
        public System.Windows.Forms.DataGridView itemtable;
        private System.Windows.Forms.TextBox itemname;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.TextBox txtSeller1;
        private System.Windows.Forms.ComboBox cmbsby;
        private System.Windows.Forms.Label lblsearchby;
        private System.Windows.Forms.DateTimePicker expDelDate;
        public System.Windows.Forms.TextBox txtcid1;
        public System.Windows.Forms.TabControl tabcontrol_CustMgt;
        public System.Windows.Forms.TabPage cst_tab;
        public System.Windows.Forms.DataGridView InvoiceNotable;
        private System.Windows.Forms.Label label37;
    }
}