﻿namespace Delivery
{
    partial class Vechicle_Mgt
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.txt_Cost = new System.Windows.Forms.TextBox();
            this.label40 = new System.Windows.Forms.Label();
            this.btn_close = new System.Windows.Forms.Button();
            this.btn_clear = new System.Windows.Forms.Button();
            this.btn_delete = new System.Windows.Forms.Button();
            this.but_update = new System.Windows.Forms.Button();
            this.btn_save = new System.Windows.Forms.Button();
            this.label7 = new System.Windows.Forms.Label();
            this.dgvVechicle = new System.Windows.Forms.DataGridView();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.txt_oilL = new System.Windows.Forms.TextBox();
            this.txt_capacity = new System.Windows.Forms.TextBox();
            this.txt_engNo = new System.Windows.Forms.TextBox();
            this.txt_chasiNo = new System.Windows.Forms.TextBox();
            this.txt_vNumber = new System.Windows.Forms.TextBox();
            this.txt_vName = new System.Windows.Forms.TextBox();
            this.txt_search = new System.Windows.Forms.TextBox();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.text_leasing = new System.Windows.Forms.TextBox();
            this.label44 = new System.Windows.Forms.Label();
            this.text_balance = new System.Windows.Forms.TextBox();
            this.comboBox1VechileNo = new System.Windows.Forms.ComboBox();
            this.bttn_balance = new System.Windows.Forms.Button();
            this.txt_phoneNo = new System.Windows.Forms.TextBox();
            this.label42 = new System.Windows.Forms.Label();
            this.datepicLend = new System.Windows.Forms.DateTimePicker();
            this.datePicLstart = new System.Windows.Forms.DateTimePicker();
            this.label_leaserID = new System.Windows.Forms.Label();
            this.txt_intialPay = new System.Windows.Forms.TextBox();
            this.txt_interstRate = new System.Windows.Forms.TextBox();
            this.label32 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.txt_Laddress = new System.Windows.Forms.TextBox();
            this.txt_Lname = new System.Windows.Forms.TextBox();
            this.label25 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.btn_closeL = new System.Windows.Forms.Button();
            this.btn_clearL = new System.Windows.Forms.Button();
            this.btn_deleteL = new System.Windows.Forms.Button();
            this.btn_updateL = new System.Windows.Forms.Button();
            this.btn_saveL = new System.Windows.Forms.Button();
            this.label28 = new System.Windows.Forms.Label();
            this.dgvLeasing = new System.Windows.Forms.DataGridView();
            this.text_serachL = new System.Windows.Forms.TextBox();
            this.label29 = new System.Windows.Forms.Label();
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.label43 = new System.Windows.Forms.Label();
            this.datePicService = new System.Windows.Forms.DateTimePicker();
            this.labelSerID = new System.Windows.Forms.Label();
            this.label_serviceID = new System.Windows.Forms.Label();
            this.label38 = new System.Windows.Forms.Label();
            this.comboBoxServiT = new System.Windows.Forms.ComboBox();
            this.butnClose = new System.Windows.Forms.Button();
            this.butnClear = new System.Windows.Forms.Button();
            this.butnDelete = new System.Windows.Forms.Button();
            this.buttnUpdate = new System.Windows.Forms.Button();
            this.buttnSave = new System.Windows.Forms.Button();
            this.txt_serAmount = new System.Windows.Forms.TextBox();
            this.label34 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.label36 = new System.Windows.Forms.Label();
            this.txt_vnumberSer = new System.Windows.Forms.TextBox();
            this.dgvService = new System.Windows.Forms.DataGridView();
            this.txt_serachSer = new System.Windows.Forms.TextBox();
            this.label37 = new System.Windows.Forms.Label();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.datePicC = new System.Windows.Forms.DateTimePicker();
            this.label_TripIdC = new System.Windows.Forms.Label();
            this.label41 = new System.Windows.Forms.Label();
            this.comboBoxCustomer = new System.Windows.Forms.ComboBox();
            this.label33 = new System.Windows.Forms.Label();
            this.txt_noofTc = new System.Windows.Forms.TextBox();
            this.txt_cweight = new System.Windows.Forms.TextBox();
            this.txt_Ctime = new System.Windows.Forms.TextBox();
            this.txt_cAddress = new System.Windows.Forms.TextBox();
            this.txt_Cname = new System.Windows.Forms.TextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.btn_clearC = new System.Windows.Forms.Button();
            this.btn_deleteC = new System.Windows.Forms.Button();
            this.btn_updateC = new System.Windows.Forms.Button();
            this.btn_saveC = new System.Windows.Forms.Button();
            this.label24 = new System.Windows.Forms.Label();
            this.txt_vnumberC = new System.Windows.Forms.TextBox();
            this.dgvCustomer = new System.Windows.Forms.DataGridView();
            this.txt_serachC = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.datePicS = new System.Windows.Forms.DateTimePicker();
            this.labelTrip_IdS = new System.Windows.Forms.Label();
            this.label39 = new System.Windows.Forms.Label();
            this.comboBoxStaffS = new System.Windows.Forms.ComboBox();
            this.txtSnoTurn = new System.Windows.Forms.TextBox();
            this.txtweightS = new System.Windows.Forms.TextBox();
            this.txt_Time = new System.Windows.Forms.TextBox();
            this.txtsAddress = new System.Windows.Forms.TextBox();
            this.txtSname = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.btn_closeS = new System.Windows.Forms.Button();
            this.btn_clearS = new System.Windows.Forms.Button();
            this.btn_deleteS = new System.Windows.Forms.Button();
            this.btn_updateS = new System.Windows.Forms.Button();
            this.btn_saveS = new System.Windows.Forms.Button();
            this.label9 = new System.Windows.Forms.Label();
            this.txt_Svnum = new System.Windows.Forms.TextBox();
            this.dgvSuppliers = new System.Windows.Forms.DataGridView();
            this.txt_searchS = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.tabPage6 = new System.Windows.Forms.TabPage();
            this.txtBoxLeaserid = new System.Windows.Forms.TextBox();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.datePickerNextServiceDate = new System.Windows.Forms.DateTimePicker();
            this.label45 = new System.Windows.Forms.Label();
            this.tabPage7 = new System.Windows.Forms.TabPage();
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.textBox_Street = new System.Windows.Forms.TextBox();
            this.textBox_City = new System.Windows.Forms.TextBox();
            this.Street = new System.Windows.Forms.Label();
            this.label47 = new System.Windows.Forms.Label();
            this.button4 = new System.Windows.Forms.Button();
            this.webBrowser1 = new System.Windows.Forms.WebBrowser();
            this.button5 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvVechicle)).BeginInit();
            this.tabPage4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvLeasing)).BeginInit();
            this.tabPage5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvService)).BeginInit();
            this.tabPage3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvCustomer)).BeginInit();
            this.tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvSuppliers)).BeginInit();
            this.tabPage6.SuspendLayout();
            this.tabPage7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage4);
            this.tabControl1.Controls.Add(this.tabPage5);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage7);
            this.tabControl1.Controls.Add(this.tabPage6);
            this.tabControl1.Location = new System.Drawing.Point(3, 3);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(811, 459);
            this.tabControl1.TabIndex = 0;
            this.tabControl1.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tabControl1_KeyPress);
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.txt_Cost);
            this.tabPage1.Controls.Add(this.label40);
            this.tabPage1.Controls.Add(this.btn_close);
            this.tabPage1.Controls.Add(this.btn_clear);
            this.tabPage1.Controls.Add(this.btn_delete);
            this.tabPage1.Controls.Add(this.but_update);
            this.tabPage1.Controls.Add(this.btn_save);
            this.tabPage1.Controls.Add(this.label7);
            this.tabPage1.Controls.Add(this.dgvVechicle);
            this.tabPage1.Controls.Add(this.label6);
            this.tabPage1.Controls.Add(this.label5);
            this.tabPage1.Controls.Add(this.label4);
            this.tabPage1.Controls.Add(this.label3);
            this.tabPage1.Controls.Add(this.label2);
            this.tabPage1.Controls.Add(this.label1);
            this.tabPage1.Controls.Add(this.txt_oilL);
            this.tabPage1.Controls.Add(this.txt_capacity);
            this.tabPage1.Controls.Add(this.txt_engNo);
            this.tabPage1.Controls.Add(this.txt_chasiNo);
            this.tabPage1.Controls.Add(this.txt_vNumber);
            this.tabPage1.Controls.Add(this.txt_vName);
            this.tabPage1.Controls.Add(this.txt_search);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(803, 433);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Vechicle";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // txt_Cost
            // 
            this.txt_Cost.Location = new System.Drawing.Point(430, 315);
            this.txt_Cost.Name = "txt_Cost";
            this.txt_Cost.Size = new System.Drawing.Size(100, 20);
            this.txt_Cost.TabIndex = 21;
            this.txt_Cost.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txt_Cost_KeyPress);
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Font = new System.Drawing.Font("Cambria", 12F);
            this.label40.Location = new System.Drawing.Point(298, 314);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(39, 19);
            this.label40.TabIndex = 20;
            this.label40.Text = "Cost";
            // 
            // btn_close
            // 
            this.btn_close.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.btn_close.Font = new System.Drawing.Font("Cambria", 12F);
            this.btn_close.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.btn_close.Location = new System.Drawing.Point(703, 370);
            this.btn_close.Name = "btn_close";
            this.btn_close.Size = new System.Drawing.Size(75, 43);
            this.btn_close.TabIndex = 19;
            this.btn_close.Text = "Close";
            this.btn_close.UseVisualStyleBackColor = false;
            this.btn_close.Click += new System.EventHandler(this.btn_close_Click);
            // 
            // btn_clear
            // 
            this.btn_clear.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.btn_clear.Font = new System.Drawing.Font("Cambria", 12F);
            this.btn_clear.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.btn_clear.Location = new System.Drawing.Point(597, 370);
            this.btn_clear.Name = "btn_clear";
            this.btn_clear.Size = new System.Drawing.Size(75, 43);
            this.btn_clear.TabIndex = 18;
            this.btn_clear.Text = "Clear";
            this.btn_clear.UseVisualStyleBackColor = false;
            this.btn_clear.Click += new System.EventHandler(this.btn_clear_Click_1);
            // 
            // btn_delete
            // 
            this.btn_delete.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.btn_delete.Font = new System.Drawing.Font("Cambria", 12F);
            this.btn_delete.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.btn_delete.Location = new System.Drawing.Point(495, 370);
            this.btn_delete.Name = "btn_delete";
            this.btn_delete.Size = new System.Drawing.Size(75, 43);
            this.btn_delete.TabIndex = 17;
            this.btn_delete.Text = "Delete";
            this.btn_delete.UseVisualStyleBackColor = false;
            this.btn_delete.Click += new System.EventHandler(this.btn_delete_Click_1);
            // 
            // but_update
            // 
            this.but_update.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.but_update.Font = new System.Drawing.Font("Cambria", 12F);
            this.but_update.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.but_update.Location = new System.Drawing.Point(378, 370);
            this.but_update.Name = "but_update";
            this.but_update.Size = new System.Drawing.Size(75, 43);
            this.but_update.TabIndex = 16;
            this.but_update.Text = "Update";
            this.but_update.UseVisualStyleBackColor = false;
            this.but_update.Click += new System.EventHandler(this.but_update_Click_1);
            // 
            // btn_save
            // 
            this.btn_save.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.btn_save.Font = new System.Drawing.Font("Cambria", 12F);
            this.btn_save.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.btn_save.Location = new System.Drawing.Point(274, 370);
            this.btn_save.Name = "btn_save";
            this.btn_save.Size = new System.Drawing.Size(75, 43);
            this.btn_save.TabIndex = 15;
            this.btn_save.Text = "Save";
            this.btn_save.UseVisualStyleBackColor = false;
            this.btn_save.Click += new System.EventHandler(this.btn_save_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Cambria", 12F);
            this.label7.Location = new System.Drawing.Point(298, 271);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(75, 19);
            this.label7.TabIndex = 14;
            this.label7.Text = "Oil Leters";
            // 
            // dgvVechicle
            // 
            this.dgvVechicle.BackgroundColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.dgvVechicle.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvVechicle.Location = new System.Drawing.Point(6, 56);
            this.dgvVechicle.Name = "dgvVechicle";
            this.dgvVechicle.Size = new System.Drawing.Size(240, 368);
            this.dgvVechicle.TabIndex = 13;
            this.dgvVechicle.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvVechicle_CellClick);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Cambria", 12F);
            this.label6.Location = new System.Drawing.Point(298, 221);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(67, 19);
            this.label6.TabIndex = 12;
            this.label6.Text = "Capacity";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Cambria", 12F);
            this.label5.Location = new System.Drawing.Point(298, 163);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(80, 19);
            this.label5.TabIndex = 11;
            this.label5.Text = "Engine No";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Cambria", 12F);
            this.label4.Location = new System.Drawing.Point(298, 112);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(121, 19);
            this.label4.TabIndex = 10;
            this.label4.Text = "Chassis Number";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Cambria", 12F);
            this.label3.Location = new System.Drawing.Point(298, 71);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(126, 19);
            this.label3.TabIndex = 9;
            this.label3.Text = "Vechicle Number";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Cambria", 12F);
            this.label2.Location = new System.Drawing.Point(298, 30);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(109, 19);
            this.label2.TabIndex = 8;
            this.label2.Text = "Vechicle Name";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Cambria", 12F);
            this.label1.Location = new System.Drawing.Point(16, 30);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(56, 19);
            this.label1.TabIndex = 7;
            this.label1.Text = "Search";
            // 
            // txt_oilL
            // 
            this.txt_oilL.Location = new System.Drawing.Point(430, 272);
            this.txt_oilL.Name = "txt_oilL";
            this.txt_oilL.Size = new System.Drawing.Size(100, 20);
            this.txt_oilL.TabIndex = 6;
            this.txt_oilL.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txt_oilL_KeyPress);
            // 
            // txt_capacity
            // 
            this.txt_capacity.Location = new System.Drawing.Point(430, 222);
            this.txt_capacity.Name = "txt_capacity";
            this.txt_capacity.Size = new System.Drawing.Size(100, 20);
            this.txt_capacity.TabIndex = 5;
            this.txt_capacity.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txt_capacity_KeyPress);
            // 
            // txt_engNo
            // 
            this.txt_engNo.Location = new System.Drawing.Point(430, 164);
            this.txt_engNo.Name = "txt_engNo";
            this.txt_engNo.Size = new System.Drawing.Size(100, 20);
            this.txt_engNo.TabIndex = 4;
            this.txt_engNo.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txt_engNo_KeyPress);
            // 
            // txt_chasiNo
            // 
            this.txt_chasiNo.Location = new System.Drawing.Point(430, 113);
            this.txt_chasiNo.Name = "txt_chasiNo";
            this.txt_chasiNo.Size = new System.Drawing.Size(100, 20);
            this.txt_chasiNo.TabIndex = 3;
            this.txt_chasiNo.TextChanged += new System.EventHandler(this.txt_chasiNo_TextChanged);
            this.txt_chasiNo.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txt_chasiNo_KeyPress);
            // 
            // txt_vNumber
            // 
            this.txt_vNumber.Location = new System.Drawing.Point(430, 70);
            this.txt_vNumber.Name = "txt_vNumber";
            this.txt_vNumber.Size = new System.Drawing.Size(100, 20);
            this.txt_vNumber.TabIndex = 2;
            this.txt_vNumber.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txt_vNumber_KeyPress);
            // 
            // txt_vName
            // 
            this.txt_vName.Font = new System.Drawing.Font("Cambria", 9.75F);
            this.txt_vName.Location = new System.Drawing.Point(430, 30);
            this.txt_vName.Name = "txt_vName";
            this.txt_vName.Size = new System.Drawing.Size(100, 23);
            this.txt_vName.TabIndex = 1;
            this.txt_vName.TextChanged += new System.EventHandler(this.txt_vName_TextChanged);
            this.txt_vName.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txt_vName_KeyPress);
            this.txt_vName.Validated += new System.EventHandler(this.txt_vName_Validated);
            // 
            // txt_search
            // 
            this.txt_search.Location = new System.Drawing.Point(116, 30);
            this.txt_search.Name = "txt_search";
            this.txt_search.Size = new System.Drawing.Size(100, 20);
            this.txt_search.TabIndex = 0;
            this.txt_search.TextChanged += new System.EventHandler(this.txt_search_TextChanged);
            // 
            // tabPage4
            // 
            this.tabPage4.Controls.Add(this.txtBoxLeaserid);
            this.tabPage4.Controls.Add(this.text_leasing);
            this.tabPage4.Controls.Add(this.label44);
            this.tabPage4.Controls.Add(this.text_balance);
            this.tabPage4.Controls.Add(this.comboBox1VechileNo);
            this.tabPage4.Controls.Add(this.bttn_balance);
            this.tabPage4.Controls.Add(this.txt_phoneNo);
            this.tabPage4.Controls.Add(this.label42);
            this.tabPage4.Controls.Add(this.datepicLend);
            this.tabPage4.Controls.Add(this.datePicLstart);
            this.tabPage4.Controls.Add(this.label_leaserID);
            this.tabPage4.Controls.Add(this.txt_intialPay);
            this.tabPage4.Controls.Add(this.txt_interstRate);
            this.tabPage4.Controls.Add(this.label32);
            this.tabPage4.Controls.Add(this.label31);
            this.tabPage4.Controls.Add(this.label30);
            this.tabPage4.Controls.Add(this.txt_Laddress);
            this.tabPage4.Controls.Add(this.txt_Lname);
            this.tabPage4.Controls.Add(this.label25);
            this.tabPage4.Controls.Add(this.label26);
            this.tabPage4.Controls.Add(this.label27);
            this.tabPage4.Controls.Add(this.btn_closeL);
            this.tabPage4.Controls.Add(this.btn_clearL);
            this.tabPage4.Controls.Add(this.btn_deleteL);
            this.tabPage4.Controls.Add(this.btn_updateL);
            this.tabPage4.Controls.Add(this.btn_saveL);
            this.tabPage4.Controls.Add(this.label28);
            this.tabPage4.Controls.Add(this.dgvLeasing);
            this.tabPage4.Controls.Add(this.text_serachL);
            this.tabPage4.Controls.Add(this.label29);
            this.tabPage4.Location = new System.Drawing.Point(4, 22);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Size = new System.Drawing.Size(803, 433);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "Leasing Details";
            this.tabPage4.UseVisualStyleBackColor = true;
            // 
            // text_leasing
            // 
            this.text_leasing.Location = new System.Drawing.Point(687, 229);
            this.text_leasing.Name = "text_leasing";
            this.text_leasing.Size = new System.Drawing.Size(100, 20);
            this.text_leasing.TabIndex = 82;
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Font = new System.Drawing.Font("Cambria", 12F);
            this.label44.Location = new System.Drawing.Point(588, 230);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(99, 19);
            this.label44.TabIndex = 81;
            this.label44.Text = "Vechicle Cost";
            // 
            // text_balance
            // 
            this.text_balance.Enabled = false;
            this.text_balance.Location = new System.Drawing.Point(687, 283);
            this.text_balance.Name = "text_balance";
            this.text_balance.Size = new System.Drawing.Size(100, 20);
            this.text_balance.TabIndex = 80;
            this.text_balance.TextChanged += new System.EventHandler(this.text_balance_TextChanged);
            // 
            // comboBox1VechileNo
            // 
            this.comboBox1VechileNo.FormattingEnabled = true;
            this.comboBox1VechileNo.Location = new System.Drawing.Point(452, 48);
            this.comboBox1VechileNo.Name = "comboBox1VechileNo";
            this.comboBox1VechileNo.Size = new System.Drawing.Size(121, 21);
            this.comboBox1VechileNo.TabIndex = 79;
            // 
            // bttn_balance
            // 
            this.bttn_balance.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.bttn_balance.Font = new System.Drawing.Font("Cambria", 12F);
            this.bttn_balance.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.bttn_balance.Location = new System.Drawing.Point(606, 270);
            this.bttn_balance.Name = "bttn_balance";
            this.bttn_balance.Size = new System.Drawing.Size(75, 43);
            this.bttn_balance.TabIndex = 78;
            this.bttn_balance.Text = "Balance";
            this.bttn_balance.UseVisualStyleBackColor = false;
            this.bttn_balance.Click += new System.EventHandler(this.bttn_balance_Click);
            // 
            // txt_phoneNo
            // 
            this.txt_phoneNo.Location = new System.Drawing.Point(452, 159);
            this.txt_phoneNo.MaxLength = 10;
            this.txt_phoneNo.Name = "txt_phoneNo";
            this.txt_phoneNo.Size = new System.Drawing.Size(258, 20);
            this.txt_phoneNo.TabIndex = 77;
            this.txt_phoneNo.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txt_phoneNo_KeyPress);
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Font = new System.Drawing.Font("Cambria", 12F);
            this.label42.Location = new System.Drawing.Point(296, 162);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(114, 19);
            this.label42.TabIndex = 76;
            this.label42.Text = "Phone Number";
            // 
            // datepicLend
            // 
            this.datepicLend.Cursor = System.Windows.Forms.Cursors.Hand;
            this.datepicLend.CustomFormat = "yyyy-MM-dd";
            this.datepicLend.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.datepicLend.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.datepicLend.Location = new System.Drawing.Point(452, 230);
            this.datepicLend.MaxDate = new System.DateTime(1999, 12, 31, 0, 0, 0, 0);
            this.datepicLend.MinDate = new System.DateTime(1963, 1, 1, 0, 0, 0, 0);
            this.datepicLend.Name = "datepicLend";
            this.datepicLend.Size = new System.Drawing.Size(126, 26);
            this.datepicLend.TabIndex = 75;
            this.datepicLend.Value = new System.DateTime(1963, 1, 1, 0, 0, 0, 0);
            // 
            // datePicLstart
            // 
            this.datePicLstart.Cursor = System.Windows.Forms.Cursors.Hand;
            this.datePicLstart.CustomFormat = "yyyy-MM-dd";
            this.datePicLstart.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.datePicLstart.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.datePicLstart.Location = new System.Drawing.Point(452, 185);
            this.datePicLstart.MaxDate = new System.DateTime(2017, 9, 21, 0, 0, 0, 0);
            this.datePicLstart.MinDate = new System.DateTime(1963, 1, 1, 0, 0, 0, 0);
            this.datePicLstart.Name = "datePicLstart";
            this.datePicLstart.Size = new System.Drawing.Size(126, 26);
            this.datePicLstart.TabIndex = 74;
            this.datePicLstart.Value = new System.DateTime(1963, 1, 1, 0, 0, 0, 0);
            // 
            // label_leaserID
            // 
            this.label_leaserID.AutoSize = true;
            this.label_leaserID.Font = new System.Drawing.Font("Cambria", 12F);
            this.label_leaserID.Location = new System.Drawing.Point(294, 18);
            this.label_leaserID.Name = "label_leaserID";
            this.label_leaserID.Size = new System.Drawing.Size(80, 19);
            this.label_leaserID.TabIndex = 72;
            this.label_leaserID.Text = "Leaser  ID";
            // 
            // txt_intialPay
            // 
            this.txt_intialPay.Location = new System.Drawing.Point(452, 321);
            this.txt_intialPay.Name = "txt_intialPay";
            this.txt_intialPay.Size = new System.Drawing.Size(100, 20);
            this.txt_intialPay.TabIndex = 71;
            this.txt_intialPay.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txt_intialPay_KeyPress_1);
            // 
            // txt_interstRate
            // 
            this.txt_interstRate.Location = new System.Drawing.Point(452, 281);
            this.txt_interstRate.Name = "txt_interstRate";
            this.txt_interstRate.Size = new System.Drawing.Size(100, 20);
            this.txt_interstRate.TabIndex = 70;
            this.txt_interstRate.TextChanged += new System.EventHandler(this.txt_interstRate_TextChanged);
            this.txt_interstRate.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txt_interstRate_KeyPress_1);
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Font = new System.Drawing.Font("Cambria", 12F);
            this.label32.Location = new System.Drawing.Point(294, 322);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(116, 19);
            this.label32.TabIndex = 69;
            this.label32.Text = "Intial Payement";
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Font = new System.Drawing.Font("Cambria", 12F);
            this.label31.Location = new System.Drawing.Point(294, 282);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(98, 19);
            this.label31.TabIndex = 68;
            this.label31.Text = "Interest Rate";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Font = new System.Drawing.Font("Cambria", 12F);
            this.label30.Location = new System.Drawing.Point(294, 236);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(72, 19);
            this.label30.TabIndex = 67;
            this.label30.Text = "End Date";
            // 
            // txt_Laddress
            // 
            this.txt_Laddress.Location = new System.Drawing.Point(452, 128);
            this.txt_Laddress.Name = "txt_Laddress";
            this.txt_Laddress.Size = new System.Drawing.Size(258, 20);
            this.txt_Laddress.TabIndex = 66;
            this.txt_Laddress.TextChanged += new System.EventHandler(this.txt_Laddress_TextChanged);
            this.txt_Laddress.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txt_Laddress_KeyPress_1);
            // 
            // txt_Lname
            // 
            this.txt_Lname.Location = new System.Drawing.Point(452, 86);
            this.txt_Lname.Name = "txt_Lname";
            this.txt_Lname.Size = new System.Drawing.Size(253, 20);
            this.txt_Lname.TabIndex = 65;
            this.txt_Lname.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txt_Lname_KeyPress_1);
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("Cambria", 12F);
            this.label25.Location = new System.Drawing.Point(294, 85);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(100, 19);
            this.label25.TabIndex = 64;
            this.label25.Text = "Leaser Name";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Font = new System.Drawing.Font("Cambria", 12F);
            this.label26.Location = new System.Drawing.Point(294, 127);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(121, 19);
            this.label26.TabIndex = 63;
            this.label26.Text = "Leaser  Address";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Font = new System.Drawing.Font("Cambria", 12F);
            this.label27.Location = new System.Drawing.Point(294, 192);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(78, 19);
            this.label27.TabIndex = 62;
            this.label27.Text = "Start Date";
            // 
            // btn_closeL
            // 
            this.btn_closeL.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.btn_closeL.Font = new System.Drawing.Font("Cambria", 12F);
            this.btn_closeL.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.btn_closeL.Location = new System.Drawing.Point(703, 372);
            this.btn_closeL.Name = "btn_closeL";
            this.btn_closeL.Size = new System.Drawing.Size(75, 43);
            this.btn_closeL.TabIndex = 61;
            this.btn_closeL.Text = "Close";
            this.btn_closeL.UseVisualStyleBackColor = false;
            this.btn_closeL.Click += new System.EventHandler(this.btn_closeL_Click);
            // 
            // btn_clearL
            // 
            this.btn_clearL.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.btn_clearL.Font = new System.Drawing.Font("Cambria", 12F);
            this.btn_clearL.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.btn_clearL.Location = new System.Drawing.Point(606, 372);
            this.btn_clearL.Name = "btn_clearL";
            this.btn_clearL.Size = new System.Drawing.Size(75, 43);
            this.btn_clearL.TabIndex = 60;
            this.btn_clearL.Text = "Clear";
            this.btn_clearL.UseVisualStyleBackColor = false;
            this.btn_clearL.Click += new System.EventHandler(this.btn_clearL_Click);
            // 
            // btn_deleteL
            // 
            this.btn_deleteL.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.btn_deleteL.Font = new System.Drawing.Font("Cambria", 12F);
            this.btn_deleteL.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.btn_deleteL.Location = new System.Drawing.Point(492, 372);
            this.btn_deleteL.Name = "btn_deleteL";
            this.btn_deleteL.Size = new System.Drawing.Size(75, 43);
            this.btn_deleteL.TabIndex = 59;
            this.btn_deleteL.Text = "Delete";
            this.btn_deleteL.UseVisualStyleBackColor = false;
            this.btn_deleteL.Click += new System.EventHandler(this.btn_deleteL_Click);
            // 
            // btn_updateL
            // 
            this.btn_updateL.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.btn_updateL.Font = new System.Drawing.Font("Cambria", 12F);
            this.btn_updateL.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.btn_updateL.Location = new System.Drawing.Point(392, 372);
            this.btn_updateL.Name = "btn_updateL";
            this.btn_updateL.Size = new System.Drawing.Size(75, 43);
            this.btn_updateL.TabIndex = 58;
            this.btn_updateL.Text = "Update";
            this.btn_updateL.UseVisualStyleBackColor = false;
            this.btn_updateL.Click += new System.EventHandler(this.btn_updateL_Click_1);
            // 
            // btn_saveL
            // 
            this.btn_saveL.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.btn_saveL.Font = new System.Drawing.Font("Cambria", 12F);
            this.btn_saveL.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.btn_saveL.Location = new System.Drawing.Point(293, 372);
            this.btn_saveL.Name = "btn_saveL";
            this.btn_saveL.Size = new System.Drawing.Size(75, 43);
            this.btn_saveL.TabIndex = 57;
            this.btn_saveL.Text = "Save";
            this.btn_saveL.UseVisualStyleBackColor = false;
            this.btn_saveL.Click += new System.EventHandler(this.btn_saveL_Click_1);
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Font = new System.Drawing.Font("Cambria", 12F);
            this.label28.Location = new System.Drawing.Point(289, 50);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(126, 19);
            this.label28.TabIndex = 56;
            this.label28.Text = "Vechicle Number";
            // 
            // dgvLeasing
            // 
            this.dgvLeasing.BackgroundColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.dgvLeasing.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvLeasing.Location = new System.Drawing.Point(25, 49);
            this.dgvLeasing.Name = "dgvLeasing";
            this.dgvLeasing.Size = new System.Drawing.Size(240, 368);
            this.dgvLeasing.TabIndex = 54;
            this.dgvLeasing.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvLeasing_CellClick);
            this.dgvLeasing.Click += new System.EventHandler(this.dgvLeasing_Click);
            // 
            // text_serachL
            // 
            this.text_serachL.Location = new System.Drawing.Point(142, 19);
            this.text_serachL.Name = "text_serachL";
            this.text_serachL.Size = new System.Drawing.Size(100, 20);
            this.text_serachL.TabIndex = 53;
            this.text_serachL.TextChanged += new System.EventHandler(this.text_serachL_TextChanged);
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Font = new System.Drawing.Font("Cambria", 12F);
            this.label29.Location = new System.Drawing.Point(45, 20);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(56, 19);
            this.label29.TabIndex = 52;
            this.label29.Text = "Search";
            // 
            // tabPage5
            // 
            this.tabPage5.Controls.Add(this.datePickerNextServiceDate);
            this.tabPage5.Controls.Add(this.label45);
            this.tabPage5.Controls.Add(this.label43);
            this.tabPage5.Controls.Add(this.datePicService);
            this.tabPage5.Controls.Add(this.labelSerID);
            this.tabPage5.Controls.Add(this.label_serviceID);
            this.tabPage5.Controls.Add(this.label38);
            this.tabPage5.Controls.Add(this.comboBoxServiT);
            this.tabPage5.Controls.Add(this.butnClose);
            this.tabPage5.Controls.Add(this.butnClear);
            this.tabPage5.Controls.Add(this.butnDelete);
            this.tabPage5.Controls.Add(this.buttnUpdate);
            this.tabPage5.Controls.Add(this.buttnSave);
            this.tabPage5.Controls.Add(this.txt_serAmount);
            this.tabPage5.Controls.Add(this.label34);
            this.tabPage5.Controls.Add(this.label35);
            this.tabPage5.Controls.Add(this.label36);
            this.tabPage5.Controls.Add(this.txt_vnumberSer);
            this.tabPage5.Controls.Add(this.dgvService);
            this.tabPage5.Controls.Add(this.txt_serachSer);
            this.tabPage5.Controls.Add(this.label37);
            this.tabPage5.Location = new System.Drawing.Point(4, 22);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Size = new System.Drawing.Size(803, 433);
            this.tabPage5.TabIndex = 4;
            this.tabPage5.Text = "Service Details";
            this.tabPage5.UseVisualStyleBackColor = true;
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.Font = new System.Drawing.Font("Cambria", 12F);
            this.label43.Location = new System.Drawing.Point(288, 281);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(0, 19);
            this.label43.TabIndex = 90;
            // 
            // datePicService
            // 
            this.datePicService.Cursor = System.Windows.Forms.Cursors.Hand;
            this.datePicService.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.datePicService.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.datePicService.Location = new System.Drawing.Point(451, 164);
            this.datePicService.MaxDate = new System.DateTime(1999, 12, 31, 0, 0, 0, 0);
            this.datePicService.MinDate = new System.DateTime(1963, 1, 1, 0, 0, 0, 0);
            this.datePicService.Name = "datePicService";
            this.datePicService.Size = new System.Drawing.Size(126, 26);
            this.datePicService.TabIndex = 89;
            this.datePicService.Value = new System.DateTime(1963, 1, 1, 0, 0, 0, 0);
            // 
            // labelSerID
            // 
            this.labelSerID.AutoSize = true;
            this.labelSerID.Font = new System.Drawing.Font("Cambria", 12F);
            this.labelSerID.Location = new System.Drawing.Point(447, 18);
            this.labelSerID.Name = "labelSerID";
            this.labelSerID.Size = new System.Drawing.Size(19, 19);
            this.labelSerID.TabIndex = 88;
            this.labelSerID.Text = "--";
            // 
            // label_serviceID
            // 
            this.label_serviceID.AutoSize = true;
            this.label_serviceID.Font = new System.Drawing.Font("Cambria", 12F);
            this.label_serviceID.Location = new System.Drawing.Point(288, 17);
            this.label_serviceID.Name = "label_serviceID";
            this.label_serviceID.Size = new System.Drawing.Size(79, 19);
            this.label_serviceID.TabIndex = 87;
            this.label_serviceID.Text = "Service ID";
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Font = new System.Drawing.Font("Cambria", 12F);
            this.label38.Location = new System.Drawing.Point(288, 113);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(97, 19);
            this.label38.TabIndex = 86;
            this.label38.Text = "Service Type";
            // 
            // comboBoxServiT
            // 
            this.comboBoxServiT.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxServiT.FormattingEnabled = true;
            this.comboBoxServiT.Items.AddRange(new object[] {
            "Annual Service",
            "Regular Service",
            "Washing"});
            this.comboBoxServiT.Location = new System.Drawing.Point(451, 113);
            this.comboBoxServiT.Name = "comboBoxServiT";
            this.comboBoxServiT.Size = new System.Drawing.Size(101, 21);
            this.comboBoxServiT.TabIndex = 85;
            // 
            // butnClose
            // 
            this.butnClose.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.butnClose.Font = new System.Drawing.Font("Cambria", 12F);
            this.butnClose.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.butnClose.Location = new System.Drawing.Point(702, 368);
            this.butnClose.Name = "butnClose";
            this.butnClose.Size = new System.Drawing.Size(75, 43);
            this.butnClose.TabIndex = 84;
            this.butnClose.Text = "Close";
            this.butnClose.UseVisualStyleBackColor = false;
            this.butnClose.Click += new System.EventHandler(this.butnClose_Click);
            // 
            // butnClear
            // 
            this.butnClear.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.butnClear.Font = new System.Drawing.Font("Cambria", 12F);
            this.butnClear.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.butnClear.Location = new System.Drawing.Point(605, 368);
            this.butnClear.Name = "butnClear";
            this.butnClear.Size = new System.Drawing.Size(75, 43);
            this.butnClear.TabIndex = 83;
            this.butnClear.Text = "Clear";
            this.butnClear.UseVisualStyleBackColor = false;
            this.butnClear.Click += new System.EventHandler(this.butnClear_Click);
            // 
            // butnDelete
            // 
            this.butnDelete.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.butnDelete.Font = new System.Drawing.Font("Cambria", 12F);
            this.butnDelete.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.butnDelete.Location = new System.Drawing.Point(491, 368);
            this.butnDelete.Name = "butnDelete";
            this.butnDelete.Size = new System.Drawing.Size(75, 43);
            this.butnDelete.TabIndex = 82;
            this.butnDelete.Text = "Delete";
            this.butnDelete.UseVisualStyleBackColor = false;
            this.butnDelete.Click += new System.EventHandler(this.butnDelete_Click);
            // 
            // buttnUpdate
            // 
            this.buttnUpdate.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.buttnUpdate.Font = new System.Drawing.Font("Cambria", 12F);
            this.buttnUpdate.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.buttnUpdate.Location = new System.Drawing.Point(391, 368);
            this.buttnUpdate.Name = "buttnUpdate";
            this.buttnUpdate.Size = new System.Drawing.Size(75, 43);
            this.buttnUpdate.TabIndex = 81;
            this.buttnUpdate.Text = "Update";
            this.buttnUpdate.UseVisualStyleBackColor = false;
            this.buttnUpdate.Click += new System.EventHandler(this.buttnUpdate_Click);
            // 
            // buttnSave
            // 
            this.buttnSave.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.buttnSave.Font = new System.Drawing.Font("Cambria", 12F);
            this.buttnSave.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.buttnSave.Location = new System.Drawing.Point(292, 368);
            this.buttnSave.Name = "buttnSave";
            this.buttnSave.Size = new System.Drawing.Size(75, 43);
            this.buttnSave.TabIndex = 80;
            this.buttnSave.Text = "Save";
            this.buttnSave.UseVisualStyleBackColor = false;
            this.buttnSave.Click += new System.EventHandler(this.buttnSave_Click_1);
            // 
            // txt_serAmount
            // 
            this.txt_serAmount.Location = new System.Drawing.Point(452, 230);
            this.txt_serAmount.Name = "txt_serAmount";
            this.txt_serAmount.Size = new System.Drawing.Size(100, 20);
            this.txt_serAmount.TabIndex = 79;
            this.txt_serAmount.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txt_serAmount_KeyPress_1);
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Font = new System.Drawing.Font("Cambria", 12F);
            this.label34.Location = new System.Drawing.Point(288, 229);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(118, 19);
            this.label34.TabIndex = 78;
            this.label34.Text = "Service Amount";
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Font = new System.Drawing.Font("Cambria", 12F);
            this.label35.Location = new System.Drawing.Point(288, 170);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(95, 19);
            this.label35.TabIndex = 77;
            this.label35.Text = "Service Date";
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Font = new System.Drawing.Font("Cambria", 12F);
            this.label36.Location = new System.Drawing.Point(288, 66);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(126, 19);
            this.label36.TabIndex = 76;
            this.label36.Text = "Vechicle Number";
            // 
            // txt_vnumberSer
            // 
            this.txt_vnumberSer.Location = new System.Drawing.Point(451, 67);
            this.txt_vnumberSer.Name = "txt_vnumberSer";
            this.txt_vnumberSer.Size = new System.Drawing.Size(100, 20);
            this.txt_vnumberSer.TabIndex = 75;
            this.txt_vnumberSer.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txt_vnumberSer_KeyPress_1);
            // 
            // dgvService
            // 
            this.dgvService.BackgroundColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.dgvService.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvService.Location = new System.Drawing.Point(15, 43);
            this.dgvService.Name = "dgvService";
            this.dgvService.Size = new System.Drawing.Size(240, 368);
            this.dgvService.TabIndex = 74;
            this.dgvService.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvService_CellClick);
            // 
            // txt_serachSer
            // 
            this.txt_serachSer.Location = new System.Drawing.Point(138, 17);
            this.txt_serachSer.Name = "txt_serachSer";
            this.txt_serachSer.Size = new System.Drawing.Size(100, 20);
            this.txt_serachSer.TabIndex = 73;
            this.txt_serachSer.TextChanged += new System.EventHandler(this.txt_serachSer_TextChanged);
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Font = new System.Drawing.Font("Cambria", 12F);
            this.label37.Location = new System.Drawing.Point(22, 16);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(56, 19);
            this.label37.TabIndex = 72;
            this.label37.Text = "Search";
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.datePicC);
            this.tabPage3.Controls.Add(this.label_TripIdC);
            this.tabPage3.Controls.Add(this.label41);
            this.tabPage3.Controls.Add(this.comboBoxCustomer);
            this.tabPage3.Controls.Add(this.label33);
            this.tabPage3.Controls.Add(this.txt_noofTc);
            this.tabPage3.Controls.Add(this.txt_cweight);
            this.tabPage3.Controls.Add(this.txt_Ctime);
            this.tabPage3.Controls.Add(this.txt_cAddress);
            this.tabPage3.Controls.Add(this.txt_Cname);
            this.tabPage3.Controls.Add(this.label18);
            this.tabPage3.Controls.Add(this.label19);
            this.tabPage3.Controls.Add(this.label20);
            this.tabPage3.Controls.Add(this.label21);
            this.tabPage3.Controls.Add(this.label22);
            this.tabPage3.Controls.Add(this.label23);
            this.tabPage3.Controls.Add(this.button1);
            this.tabPage3.Controls.Add(this.btn_clearC);
            this.tabPage3.Controls.Add(this.btn_deleteC);
            this.tabPage3.Controls.Add(this.btn_updateC);
            this.tabPage3.Controls.Add(this.btn_saveC);
            this.tabPage3.Controls.Add(this.label24);
            this.tabPage3.Controls.Add(this.txt_vnumberC);
            this.tabPage3.Controls.Add(this.dgvCustomer);
            this.tabPage3.Controls.Add(this.txt_serachC);
            this.tabPage3.Controls.Add(this.label17);
            this.tabPage3.Location = new System.Drawing.Point(4, 22);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Size = new System.Drawing.Size(803, 433);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "To Customers";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // datePicC
            // 
            this.datePicC.Cursor = System.Windows.Forms.Cursors.Hand;
            this.datePicC.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.datePicC.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.datePicC.Location = new System.Drawing.Point(428, 108);
            this.datePicC.MaxDate = new System.DateTime(1999, 12, 31, 0, 0, 0, 0);
            this.datePicC.MinDate = new System.DateTime(1963, 1, 1, 0, 0, 0, 0);
            this.datePicC.Name = "datePicC";
            this.datePicC.Size = new System.Drawing.Size(126, 26);
            this.datePicC.TabIndex = 59;
            this.datePicC.Value = new System.DateTime(1963, 1, 1, 0, 0, 0, 0);
            // 
            // label_TripIdC
            // 
            this.label_TripIdC.AutoSize = true;
            this.label_TripIdC.Font = new System.Drawing.Font("Cambria", 12F);
            this.label_TripIdC.Location = new System.Drawing.Point(424, 0);
            this.label_TripIdC.Name = "label_TripIdC";
            this.label_TripIdC.Size = new System.Drawing.Size(19, 19);
            this.label_TripIdC.TabIndex = 58;
            this.label_TripIdC.Text = "--";
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Font = new System.Drawing.Font("Cambria", 12F);
            this.label41.Location = new System.Drawing.Point(272, 0);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(57, 19);
            this.label41.TabIndex = 57;
            this.label41.Text = "Trip ID";
            // 
            // comboBoxCustomer
            // 
            this.comboBoxCustomer.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxCustomer.FormattingEnabled = true;
            this.comboBoxCustomer.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10"});
            this.comboBoxCustomer.Location = new System.Drawing.Point(429, 333);
            this.comboBoxCustomer.Name = "comboBoxCustomer";
            this.comboBoxCustomer.Size = new System.Drawing.Size(101, 21);
            this.comboBoxCustomer.TabIndex = 56;
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Font = new System.Drawing.Font("Cambria", 12F);
            this.label33.Location = new System.Drawing.Point(273, 335);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(58, 19);
            this.label33.TabIndex = 55;
            this.label33.Text = "Staff Id";
            // 
            // txt_noofTc
            // 
            this.txt_noofTc.Location = new System.Drawing.Point(429, 247);
            this.txt_noofTc.Name = "txt_noofTc";
            this.txt_noofTc.Size = new System.Drawing.Size(100, 20);
            this.txt_noofTc.TabIndex = 54;
            this.txt_noofTc.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txt_noofTc_KeyPress_1);
            // 
            // txt_cweight
            // 
            this.txt_cweight.Location = new System.Drawing.Point(431, 202);
            this.txt_cweight.Name = "txt_cweight";
            this.txt_cweight.Size = new System.Drawing.Size(100, 20);
            this.txt_cweight.TabIndex = 53;
            this.txt_cweight.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txt_cweight_KeyPress_1);
            // 
            // txt_Ctime
            // 
            this.txt_Ctime.Location = new System.Drawing.Point(428, 153);
            this.txt_Ctime.Name = "txt_Ctime";
            this.txt_Ctime.Size = new System.Drawing.Size(101, 20);
            this.txt_Ctime.TabIndex = 52;
            this.txt_Ctime.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txt_Ctime_KeyPress_1);
            // 
            // txt_cAddress
            // 
            this.txt_cAddress.Location = new System.Drawing.Point(431, 73);
            this.txt_cAddress.Name = "txt_cAddress";
            this.txt_cAddress.Size = new System.Drawing.Size(258, 20);
            this.txt_cAddress.TabIndex = 51;
            this.txt_cAddress.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txt_cAddress_KeyPress_1);
            // 
            // txt_Cname
            // 
            this.txt_Cname.Location = new System.Drawing.Point(431, 31);
            this.txt_Cname.Name = "txt_Cname";
            this.txt_Cname.Size = new System.Drawing.Size(253, 20);
            this.txt_Cname.TabIndex = 50;
            this.txt_Cname.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txt_Cname_KeyPress_1);
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Cambria", 12F);
            this.label18.Location = new System.Drawing.Point(273, 248);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(86, 19);
            this.label18.TabIndex = 49;
            this.label18.Text = "No Of Turn";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Cambria", 12F);
            this.label19.Location = new System.Drawing.Point(266, 203);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(96, 19);
            this.label19.TabIndex = 48;
            this.label19.Text = "Stock weight";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Cambria", 12F);
            this.label20.Location = new System.Drawing.Point(266, 32);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(120, 19);
            this.label20.TabIndex = 47;
            this.label20.Text = "Customer Name";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Cambria", 12F);
            this.label21.Location = new System.Drawing.Point(266, 74);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(137, 19);
            this.label21.TabIndex = 46;
            this.label21.Text = "Customer Address";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Cambria", 12F);
            this.label22.Location = new System.Drawing.Point(273, 108);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(41, 19);
            this.label22.TabIndex = 45;
            this.label22.Text = "Date";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Cambria", 12F);
            this.label23.Location = new System.Drawing.Point(273, 154);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(43, 19);
            this.label23.TabIndex = 44;
            this.label23.Text = "Time";
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.button1.Font = new System.Drawing.Font("Cambria", 12F);
            this.button1.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.button1.Location = new System.Drawing.Point(687, 373);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 43);
            this.button1.TabIndex = 43;
            this.button1.Text = "Close";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // btn_clearC
            // 
            this.btn_clearC.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.btn_clearC.Font = new System.Drawing.Font("Cambria", 12F);
            this.btn_clearC.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.btn_clearC.Location = new System.Drawing.Point(590, 373);
            this.btn_clearC.Name = "btn_clearC";
            this.btn_clearC.Size = new System.Drawing.Size(75, 43);
            this.btn_clearC.TabIndex = 42;
            this.btn_clearC.Text = "Clear";
            this.btn_clearC.UseVisualStyleBackColor = false;
            this.btn_clearC.Click += new System.EventHandler(this.btn_clearC_Click);
            // 
            // btn_deleteC
            // 
            this.btn_deleteC.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.btn_deleteC.Font = new System.Drawing.Font("Cambria", 12F);
            this.btn_deleteC.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.btn_deleteC.Location = new System.Drawing.Point(476, 373);
            this.btn_deleteC.Name = "btn_deleteC";
            this.btn_deleteC.Size = new System.Drawing.Size(75, 43);
            this.btn_deleteC.TabIndex = 41;
            this.btn_deleteC.Text = "Delete";
            this.btn_deleteC.UseVisualStyleBackColor = false;
            this.btn_deleteC.Click += new System.EventHandler(this.btn_deleteC_Click);
            // 
            // btn_updateC
            // 
            this.btn_updateC.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.btn_updateC.Font = new System.Drawing.Font("Cambria", 12F);
            this.btn_updateC.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.btn_updateC.Location = new System.Drawing.Point(376, 373);
            this.btn_updateC.Name = "btn_updateC";
            this.btn_updateC.Size = new System.Drawing.Size(75, 43);
            this.btn_updateC.TabIndex = 40;
            this.btn_updateC.Text = "Update";
            this.btn_updateC.UseVisualStyleBackColor = false;
            this.btn_updateC.Click += new System.EventHandler(this.btn_updateC_Click);
            // 
            // btn_saveC
            // 
            this.btn_saveC.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.btn_saveC.Font = new System.Drawing.Font("Cambria", 12F);
            this.btn_saveC.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.btn_saveC.Location = new System.Drawing.Point(277, 373);
            this.btn_saveC.Name = "btn_saveC";
            this.btn_saveC.Size = new System.Drawing.Size(75, 43);
            this.btn_saveC.TabIndex = 39;
            this.btn_saveC.Text = "Save";
            this.btn_saveC.UseVisualStyleBackColor = false;
            this.btn_saveC.Click += new System.EventHandler(this.btn_saveC_Click);
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("Cambria", 12F);
            this.label24.Location = new System.Drawing.Point(266, 294);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(126, 19);
            this.label24.TabIndex = 38;
            this.label24.Text = "Vechicle Number";
            // 
            // txt_vnumberC
            // 
            this.txt_vnumberC.Location = new System.Drawing.Point(430, 293);
            this.txt_vnumberC.Name = "txt_vnumberC";
            this.txt_vnumberC.Size = new System.Drawing.Size(100, 20);
            this.txt_vnumberC.TabIndex = 37;
            this.txt_vnumberC.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txt_vnumberC_KeyPress_1);
            // 
            // dgvCustomer
            // 
            this.dgvCustomer.BackgroundColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.dgvCustomer.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvCustomer.Location = new System.Drawing.Point(9, 50);
            this.dgvCustomer.Name = "dgvCustomer";
            this.dgvCustomer.Size = new System.Drawing.Size(240, 368);
            this.dgvCustomer.TabIndex = 17;
            this.dgvCustomer.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvCustomer_CellClick);
            // 
            // txt_serachC
            // 
            this.txt_serachC.Location = new System.Drawing.Point(126, 20);
            this.txt_serachC.Name = "txt_serachC";
            this.txt_serachC.Size = new System.Drawing.Size(100, 20);
            this.txt_serachC.TabIndex = 16;
            this.txt_serachC.TextChanged += new System.EventHandler(this.txt_serachC_TextChanged);
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Cambria", 12F);
            this.label17.Location = new System.Drawing.Point(29, 21);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(56, 19);
            this.label17.TabIndex = 15;
            this.label17.Text = "Search";
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.datePicS);
            this.tabPage2.Controls.Add(this.labelTrip_IdS);
            this.tabPage2.Controls.Add(this.label39);
            this.tabPage2.Controls.Add(this.comboBoxStaffS);
            this.tabPage2.Controls.Add(this.txtSnoTurn);
            this.tabPage2.Controls.Add(this.txtweightS);
            this.tabPage2.Controls.Add(this.txt_Time);
            this.tabPage2.Controls.Add(this.txtsAddress);
            this.tabPage2.Controls.Add(this.txtSname);
            this.tabPage2.Controls.Add(this.label16);
            this.tabPage2.Controls.Add(this.label15);
            this.tabPage2.Controls.Add(this.label14);
            this.tabPage2.Controls.Add(this.label13);
            this.tabPage2.Controls.Add(this.label12);
            this.tabPage2.Controls.Add(this.label11);
            this.tabPage2.Controls.Add(this.label10);
            this.tabPage2.Controls.Add(this.btn_closeS);
            this.tabPage2.Controls.Add(this.btn_clearS);
            this.tabPage2.Controls.Add(this.btn_deleteS);
            this.tabPage2.Controls.Add(this.btn_updateS);
            this.tabPage2.Controls.Add(this.btn_saveS);
            this.tabPage2.Controls.Add(this.label9);
            this.tabPage2.Controls.Add(this.txt_Svnum);
            this.tabPage2.Controls.Add(this.dgvSuppliers);
            this.tabPage2.Controls.Add(this.txt_searchS);
            this.tabPage2.Controls.Add(this.label8);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(803, 433);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "From Suppliers";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // datePicS
            // 
            this.datePicS.Cursor = System.Windows.Forms.Cursors.Hand;
            this.datePicS.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.datePicS.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.datePicS.Location = new System.Drawing.Point(424, 115);
            this.datePicS.MaxDate = new System.DateTime(1999, 12, 31, 0, 0, 0, 0);
            this.datePicS.MinDate = new System.DateTime(1963, 1, 1, 0, 0, 0, 0);
            this.datePicS.Name = "datePicS";
            this.datePicS.Size = new System.Drawing.Size(126, 26);
            this.datePicS.TabIndex = 41;
            this.datePicS.Value = new System.DateTime(1963, 1, 1, 0, 0, 0, 0);
            // 
            // labelTrip_IdS
            // 
            this.labelTrip_IdS.AutoSize = true;
            this.labelTrip_IdS.Font = new System.Drawing.Font("Cambria", 12F);
            this.labelTrip_IdS.Location = new System.Drawing.Point(421, 15);
            this.labelTrip_IdS.Name = "labelTrip_IdS";
            this.labelTrip_IdS.Size = new System.Drawing.Size(19, 19);
            this.labelTrip_IdS.TabIndex = 40;
            this.labelTrip_IdS.Text = "--";
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Font = new System.Drawing.Font("Cambria", 12F);
            this.label39.Location = new System.Drawing.Point(278, 15);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(87, 19);
            this.label39.TabIndex = 39;
            this.label39.Text = "Supplier ID";
            // 
            // comboBoxStaffS
            // 
            this.comboBoxStaffS.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxStaffS.FormattingEnabled = true;
            this.comboBoxStaffS.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10"});
            this.comboBoxStaffS.Location = new System.Drawing.Point(424, 342);
            this.comboBoxStaffS.Name = "comboBoxStaffS";
            this.comboBoxStaffS.Size = new System.Drawing.Size(101, 21);
            this.comboBoxStaffS.TabIndex = 38;
            // 
            // txtSnoTurn
            // 
            this.txtSnoTurn.Location = new System.Drawing.Point(425, 250);
            this.txtSnoTurn.Name = "txtSnoTurn";
            this.txtSnoTurn.Size = new System.Drawing.Size(100, 20);
            this.txtSnoTurn.TabIndex = 36;
            this.txtSnoTurn.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtSnoTurn_KeyPress_1);
            // 
            // txtweightS
            // 
            this.txtweightS.Location = new System.Drawing.Point(425, 199);
            this.txtweightS.Name = "txtweightS";
            this.txtweightS.Size = new System.Drawing.Size(100, 20);
            this.txtweightS.TabIndex = 35;
            this.txtweightS.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtweightS_KeyPress_1);
            // 
            // txt_Time
            // 
            this.txt_Time.Location = new System.Drawing.Point(424, 155);
            this.txt_Time.Name = "txt_Time";
            this.txt_Time.Size = new System.Drawing.Size(101, 20);
            this.txt_Time.TabIndex = 34;
            this.txt_Time.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txt_Time_KeyPress_1);
            // 
            // txtsAddress
            // 
            this.txtsAddress.Location = new System.Drawing.Point(424, 85);
            this.txtsAddress.Name = "txtsAddress";
            this.txtsAddress.Size = new System.Drawing.Size(258, 20);
            this.txtsAddress.TabIndex = 33;
            this.txtsAddress.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtsAddress_KeyPress_1);
            // 
            // txtSname
            // 
            this.txtSname.Location = new System.Drawing.Point(424, 48);
            this.txtSname.Name = "txtSname";
            this.txtSname.Size = new System.Drawing.Size(253, 20);
            this.txtSname.TabIndex = 32;
            this.txtSname.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtSname_KeyPress_1);
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Cambria", 12F);
            this.label16.Location = new System.Drawing.Point(280, 344);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(58, 19);
            this.label16.TabIndex = 31;
            this.label16.Text = "Staff Id";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Cambria", 12F);
            this.label15.Location = new System.Drawing.Point(278, 250);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(86, 19);
            this.label15.TabIndex = 30;
            this.label15.Text = "No Of Turn";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Cambria", 12F);
            this.label14.Location = new System.Drawing.Point(278, 201);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(96, 19);
            this.label14.TabIndex = 29;
            this.label14.Text = "Stock weight";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Cambria", 12F);
            this.label13.Location = new System.Drawing.Point(282, 49);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(111, 19);
            this.label13.TabIndex = 28;
            this.label13.Text = "Supplier Name";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Cambria", 12F);
            this.label12.Location = new System.Drawing.Point(278, 86);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(128, 19);
            this.label12.TabIndex = 27;
            this.label12.Text = "Supplier Address";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Cambria", 12F);
            this.label11.Location = new System.Drawing.Point(282, 121);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(41, 19);
            this.label11.TabIndex = 26;
            this.label11.Text = "Date";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Cambria", 12F);
            this.label10.Location = new System.Drawing.Point(280, 156);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(43, 19);
            this.label10.TabIndex = 25;
            this.label10.Text = "Time";
            // 
            // btn_closeS
            // 
            this.btn_closeS.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.btn_closeS.Font = new System.Drawing.Font("Cambria", 12F);
            this.btn_closeS.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.btn_closeS.Location = new System.Drawing.Point(681, 384);
            this.btn_closeS.Name = "btn_closeS";
            this.btn_closeS.Size = new System.Drawing.Size(75, 43);
            this.btn_closeS.TabIndex = 24;
            this.btn_closeS.Text = "Close";
            this.btn_closeS.UseVisualStyleBackColor = false;
            this.btn_closeS.Click += new System.EventHandler(this.btn_closeS_Click);
            // 
            // btn_clearS
            // 
            this.btn_clearS.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.btn_clearS.Font = new System.Drawing.Font("Cambria", 12F);
            this.btn_clearS.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.btn_clearS.Location = new System.Drawing.Point(575, 384);
            this.btn_clearS.Name = "btn_clearS";
            this.btn_clearS.Size = new System.Drawing.Size(75, 43);
            this.btn_clearS.TabIndex = 23;
            this.btn_clearS.Text = "Clear";
            this.btn_clearS.UseVisualStyleBackColor = false;
            this.btn_clearS.Click += new System.EventHandler(this.btn_clearS_Click_1);
            // 
            // btn_deleteS
            // 
            this.btn_deleteS.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.btn_deleteS.Font = new System.Drawing.Font("Cambria", 12F);
            this.btn_deleteS.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.btn_deleteS.Location = new System.Drawing.Point(473, 384);
            this.btn_deleteS.Name = "btn_deleteS";
            this.btn_deleteS.Size = new System.Drawing.Size(75, 43);
            this.btn_deleteS.TabIndex = 22;
            this.btn_deleteS.Text = "Delete";
            this.btn_deleteS.UseVisualStyleBackColor = false;
            this.btn_deleteS.Click += new System.EventHandler(this.btn_deleteS_Click);
            // 
            // btn_updateS
            // 
            this.btn_updateS.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.btn_updateS.Font = new System.Drawing.Font("Cambria", 12F);
            this.btn_updateS.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.btn_updateS.Location = new System.Drawing.Point(356, 384);
            this.btn_updateS.Name = "btn_updateS";
            this.btn_updateS.Size = new System.Drawing.Size(75, 43);
            this.btn_updateS.TabIndex = 21;
            this.btn_updateS.Text = "Update";
            this.btn_updateS.UseVisualStyleBackColor = false;
            this.btn_updateS.Click += new System.EventHandler(this.btn_updateS_Click);
            // 
            // btn_saveS
            // 
            this.btn_saveS.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.btn_saveS.Font = new System.Drawing.Font("Cambria", 12F);
            this.btn_saveS.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.btn_saveS.Location = new System.Drawing.Point(252, 384);
            this.btn_saveS.Name = "btn_saveS";
            this.btn_saveS.Size = new System.Drawing.Size(75, 43);
            this.btn_saveS.TabIndex = 20;
            this.btn_saveS.Text = "Save";
            this.btn_saveS.UseVisualStyleBackColor = false;
            this.btn_saveS.Click += new System.EventHandler(this.btn_saveS_Click_1);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Cambria", 12F);
            this.label9.Location = new System.Drawing.Point(280, 305);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(126, 19);
            this.label9.TabIndex = 16;
            this.label9.Text = "Vechicle Number";
            // 
            // txt_Svnum
            // 
            this.txt_Svnum.Location = new System.Drawing.Point(425, 306);
            this.txt_Svnum.Name = "txt_Svnum";
            this.txt_Svnum.Size = new System.Drawing.Size(100, 20);
            this.txt_Svnum.TabIndex = 15;
            this.txt_Svnum.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txt_Svnum_KeyPress_1);
            // 
            // dgvSuppliers
            // 
            this.dgvSuppliers.BackgroundColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.dgvSuppliers.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvSuppliers.Location = new System.Drawing.Point(6, 59);
            this.dgvSuppliers.Name = "dgvSuppliers";
            this.dgvSuppliers.Size = new System.Drawing.Size(240, 368);
            this.dgvSuppliers.TabIndex = 14;
            this.dgvSuppliers.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvSuppliers_CellClick);
            // 
            // txt_searchS
            // 
            this.txt_searchS.Location = new System.Drawing.Point(123, 29);
            this.txt_searchS.Name = "txt_searchS";
            this.txt_searchS.Size = new System.Drawing.Size(100, 20);
            this.txt_searchS.TabIndex = 9;
            this.txt_searchS.TextChanged += new System.EventHandler(this.txt_searchS_TextChanged);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Cambria", 12F);
            this.label8.Location = new System.Drawing.Point(26, 30);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(56, 19);
            this.label8.TabIndex = 8;
            this.label8.Text = "Search";
            // 
            // tabPage6
            // 
            this.tabPage6.Controls.Add(this.button3);
            this.tabPage6.Controls.Add(this.button2);
            this.tabPage6.Location = new System.Drawing.Point(4, 22);
            this.tabPage6.Name = "tabPage6";
            this.tabPage6.Size = new System.Drawing.Size(803, 433);
            this.tabPage6.TabIndex = 5;
            this.tabPage6.Text = "Reports";
            this.tabPage6.UseVisualStyleBackColor = true;
            // 
            // txtBoxLeaserid
            // 
            this.txtBoxLeaserid.Enabled = false;
            this.txtBoxLeaserid.Location = new System.Drawing.Point(452, 17);
            this.txtBoxLeaserid.Name = "txtBoxLeaserid";
            this.txtBoxLeaserid.Size = new System.Drawing.Size(100, 20);
            this.txtBoxLeaserid.TabIndex = 83;
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.button2.Font = new System.Drawing.Font("Cambria", 12F);
            this.button2.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.button2.Location = new System.Drawing.Point(62, 47);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(169, 43);
            this.button2.TabIndex = 81;
            this.button2.Text = "Leasing Report";
            this.button2.UseVisualStyleBackColor = false;
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.button3.Font = new System.Drawing.Font("Cambria", 12F);
            this.button3.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.button3.Location = new System.Drawing.Point(62, 168);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(169, 43);
            this.button3.TabIndex = 82;
            this.button3.Text = "Service Report";
            this.button3.UseVisualStyleBackColor = false;
            // 
            // datePickerNextServiceDate
            // 
            this.datePickerNextServiceDate.Cursor = System.Windows.Forms.Cursors.Hand;
            this.datePickerNextServiceDate.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.datePickerNextServiceDate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.datePickerNextServiceDate.Location = new System.Drawing.Point(453, 295);
            this.datePickerNextServiceDate.MaxDate = new System.DateTime(1999, 12, 31, 0, 0, 0, 0);
            this.datePickerNextServiceDate.MinDate = new System.DateTime(1963, 1, 1, 0, 0, 0, 0);
            this.datePickerNextServiceDate.Name = "datePickerNextServiceDate";
            this.datePickerNextServiceDate.Size = new System.Drawing.Size(126, 26);
            this.datePickerNextServiceDate.TabIndex = 92;
            this.datePickerNextServiceDate.Value = new System.DateTime(1963, 1, 1, 0, 0, 0, 0);
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.Font = new System.Drawing.Font("Cambria", 12F);
            this.label45.Location = new System.Drawing.Point(290, 301);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(131, 19);
            this.label45.TabIndex = 91;
            this.label45.Text = "Next Service Date";
            // 
            // tabPage7
            // 
            this.tabPage7.Controls.Add(this.splitContainer1);
            this.tabPage7.Location = new System.Drawing.Point(4, 22);
            this.tabPage7.Name = "tabPage7";
            this.tabPage7.Size = new System.Drawing.Size(803, 433);
            this.tabPage7.TabIndex = 6;
            this.tabPage7.Text = "Maps";
            this.tabPage7.UseVisualStyleBackColor = true;
            // 
            // splitContainer1
            // 
            this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer1.Location = new System.Drawing.Point(0, 0);
            this.splitContainer1.Name = "splitContainer1";
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.button5);
            this.splitContainer1.Panel1.Controls.Add(this.button6);
            this.splitContainer1.Panel1.Controls.Add(this.button4);
            this.splitContainer1.Panel1.Controls.Add(this.label47);
            this.splitContainer1.Panel1.Controls.Add(this.Street);
            this.splitContainer1.Panel1.Controls.Add(this.textBox_City);
            this.splitContainer1.Panel1.Controls.Add(this.textBox_Street);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.webBrowser1);
            this.splitContainer1.Size = new System.Drawing.Size(803, 433);
            this.splitContainer1.SplitterDistance = 267;
            this.splitContainer1.TabIndex = 0;
            // 
            // textBox_Street
            // 
            this.textBox_Street.Location = new System.Drawing.Point(125, 34);
            this.textBox_Street.Name = "textBox_Street";
            this.textBox_Street.Size = new System.Drawing.Size(100, 20);
            this.textBox_Street.TabIndex = 0;
            // 
            // textBox_City
            // 
            this.textBox_City.Location = new System.Drawing.Point(125, 130);
            this.textBox_City.Name = "textBox_City";
            this.textBox_City.Size = new System.Drawing.Size(100, 20);
            this.textBox_City.TabIndex = 1;
            // 
            // Street
            // 
            this.Street.AutoSize = true;
            this.Street.Font = new System.Drawing.Font("Cambria", 12F);
            this.Street.Location = new System.Drawing.Point(30, 34);
            this.Street.Name = "Street";
            this.Street.Size = new System.Drawing.Size(50, 19);
            this.Street.TabIndex = 2;
            this.Street.Text = "Street";
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.label47.Font = new System.Drawing.Font("Cambria", 12F);
            this.label47.Location = new System.Drawing.Point(30, 137);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(35, 19);
            this.label47.TabIndex = 3;
            this.label47.Text = "City";
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.button4.Font = new System.Drawing.Font("Cambria", 12F);
            this.button4.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.button4.Location = new System.Drawing.Point(77, 212);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(75, 43);
            this.button4.TabIndex = 58;
            this.button4.Text = "Search";
            this.button4.UseVisualStyleBackColor = false;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // webBrowser1
            // 
            this.webBrowser1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.webBrowser1.Location = new System.Drawing.Point(0, 0);
            this.webBrowser1.MinimumSize = new System.Drawing.Size(20, 20);
            this.webBrowser1.Name = "webBrowser1";
            this.webBrowser1.Size = new System.Drawing.Size(532, 433);
            this.webBrowser1.TabIndex = 0;
            // 
            // button5
            // 
            this.button5.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.button5.Font = new System.Drawing.Font("Cambria", 12F);
            this.button5.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.button5.Location = new System.Drawing.Point(140, 324);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(75, 43);
            this.button5.TabIndex = 63;
            this.button5.Text = "Close";
            this.button5.UseVisualStyleBackColor = false;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // button6
            // 
            this.button6.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.button6.Font = new System.Drawing.Font("Cambria", 12F);
            this.button6.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.button6.Location = new System.Drawing.Point(43, 324);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(75, 43);
            this.button6.TabIndex = 62;
            this.button6.Text = "Clear";
            this.button6.UseVisualStyleBackColor = false;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // Vechicle_Mgt
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(810, 461);
            this.Controls.Add(this.tabControl1);
            this.Name = "Vechicle_Mgt";
            this.Text = "Vehicle Mgt";
            this.Load += new System.EventHandler(this.Form1_Load_1);
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvVechicle)).EndInit();
            this.tabPage4.ResumeLayout(false);
            this.tabPage4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvLeasing)).EndInit();
            this.tabPage5.ResumeLayout(false);
            this.tabPage5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvService)).EndInit();
            this.tabPage3.ResumeLayout(false);
            this.tabPage3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvCustomer)).EndInit();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvSuppliers)).EndInit();
            this.tabPage6.ResumeLayout(false);
            this.tabPage7.ResumeLayout(false);
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel1.PerformLayout();
            this.splitContainer1.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
            this.splitContainer1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.TabPage tabPage5;
        private System.Windows.Forms.TabPage tabPage6;
        private System.Windows.Forms.Button btn_close;
        private System.Windows.Forms.Button btn_clear;
        private System.Windows.Forms.Button btn_delete;
        private System.Windows.Forms.Button but_update;
        private System.Windows.Forms.Button btn_save;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.DataGridView dgvVechicle;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txt_oilL;
        private System.Windows.Forms.TextBox txt_capacity;
        private System.Windows.Forms.TextBox txt_engNo;
        private System.Windows.Forms.TextBox txt_chasiNo;
        private System.Windows.Forms.TextBox txt_vNumber;
        private System.Windows.Forms.TextBox txt_vName;
        private System.Windows.Forms.TextBox txt_search;
        private System.Windows.Forms.ComboBox comboBoxStaffS;
        private System.Windows.Forms.TextBox txtSnoTurn;
        private System.Windows.Forms.TextBox txtweightS;
        private System.Windows.Forms.TextBox txt_Time;
        private System.Windows.Forms.TextBox txtsAddress;
        private System.Windows.Forms.TextBox txtSname;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Button btn_closeS;
        private System.Windows.Forms.Button btn_clearS;
        private System.Windows.Forms.Button btn_deleteS;
        private System.Windows.Forms.Button btn_updateS;
        private System.Windows.Forms.Button btn_saveS;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox txt_Svnum;
        private System.Windows.Forms.DataGridView dgvSuppliers;
        private System.Windows.Forms.TextBox txt_searchS;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.DataGridView dgvCustomer;
        private System.Windows.Forms.TextBox txt_serachC;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.TextBox txt_noofTc;
        private System.Windows.Forms.TextBox txt_cweight;
        private System.Windows.Forms.TextBox txt_Ctime;
        private System.Windows.Forms.TextBox txt_cAddress;
        private System.Windows.Forms.TextBox txt_Cname;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button btn_clearC;
        private System.Windows.Forms.Button btn_deleteC;
        private System.Windows.Forms.Button btn_updateC;
        private System.Windows.Forms.Button btn_saveC;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.TextBox txt_vnumberC;
        private System.Windows.Forms.TextBox txt_intialPay;
        private System.Windows.Forms.TextBox txt_interstRate;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.TextBox txt_Laddress;
        private System.Windows.Forms.TextBox txt_Lname;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Button btn_closeL;
        private System.Windows.Forms.Button btn_clearL;
        private System.Windows.Forms.Button btn_deleteL;
        private System.Windows.Forms.Button btn_updateL;
        private System.Windows.Forms.Button btn_saveL;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.DataGridView dgvLeasing;
        private System.Windows.Forms.TextBox text_serachL;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.ComboBox comboBoxCustomer;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.ComboBox comboBoxServiT;
        private System.Windows.Forms.Button butnClose;
        private System.Windows.Forms.Button butnClear;
        private System.Windows.Forms.Button butnDelete;
        private System.Windows.Forms.Button buttnUpdate;
        private System.Windows.Forms.Button buttnSave;
        private System.Windows.Forms.TextBox txt_serAmount;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.TextBox txt_vnumberSer;
        private System.Windows.Forms.DataGridView dgvService;
        private System.Windows.Forms.TextBox txt_serachSer;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Label labelTrip_IdS;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Label label_TripIdC;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.Label label_leaserID;
        private System.Windows.Forms.Label labelSerID;
        private System.Windows.Forms.Label label_serviceID;
        private System.Windows.Forms.DateTimePicker datePicS;
        private System.Windows.Forms.DateTimePicker datePicC;
        private System.Windows.Forms.DateTimePicker datepicLend;
        private System.Windows.Forms.DateTimePicker datePicLstart;
        private System.Windows.Forms.DateTimePicker datePicService;
        private System.Windows.Forms.TextBox txt_Cost;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.TextBox txt_phoneNo;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.Button bttn_balance;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.ComboBox comboBox1VechileNo;
        private System.Windows.Forms.TextBox text_balance;
        private System.Windows.Forms.TextBox text_leasing;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.TextBox txtBoxLeaserid;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.DateTimePicker datePickerNextServiceDate;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.TabPage tabPage7;
        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.Label Street;
        private System.Windows.Forms.TextBox textBox_City;
        private System.Windows.Forms.TextBox textBox_Street;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.WebBrowser webBrowser1;
    }
}

